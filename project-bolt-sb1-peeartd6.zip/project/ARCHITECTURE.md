# System Architecture

## Overview

This document describes the architecture of the AI Email Triage system, designed for production deployment and hackathon demonstrations.

## System Components

```
┌─────────────────────────────────────────────────────────────────┐
│                        USER INTERFACE                            │
│                   (React Dashboard - Port 5173)                  │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐      │
│  │  Email   │  │  Email   │  │   AI      │  │  Stats   │      │
│  │  List    │  │  Detail  │  │ Decision  │  │  Panel   │      │
│  └──────────┘  └──────────┘  └──────────┘  └──────────┘      │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                    STATE MANAGEMENT                              │
│                    (EmailContext)                                │
│                                                                   │
│  • Email list state                                              │
│  • AI decisions cache                                            │
│  • Selected email tracking                                       │
│  • Processing status                                             │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                    SERVICE LAYER                                 │
│                                                                   │
│  ┌──────────────┐         ┌──────────────┐                     │
│  │  AI Agent    │         │   Baseline   │                     │
│  │  Service     │         │    Agent     │                     │
│  └──────────────┘         └──────────────┘                     │
│         │                        │                               │
│         ├────────────────────────┤                              │
│         ▼                        ▼                               │
│  ┌─────────────────────────────────────┐                       │
│  │     Decision Processing Engine       │                       │
│  │  • Category Classification           │                       │
│  │  • Priority Calculation              │                       │
│  │  • Sentiment Analysis                │                       │
│  │  • Escalation Logic                  │                       │
│  │  • Response Generation               │                       │
│  └─────────────────────────────────────┘                       │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                    DATA LAYER                                    │
│                                                                   │
│  ┌──────────────┐         ┌──────────────┐                     │
│  │  Email       │         │  Ground      │                     │
│  │  Dataset     │         │  Truth       │                     │
│  │  (50 emails) │         │  Labels      │                     │
│  └──────────────┘         └──────────────┘                     │
└─────────────────────────────────────────────────────────────────┘
```

## OpenEnv Training Environment

```
┌─────────────────────────────────────────────────────────────────┐
│                    OpenEnv Environment                           │
│                 (EmailTriageEnv - Python)                        │
│                                                                   │
│  ┌──────────────────────────────────────────────────────┐      │
│  │  reset()                                              │      │
│  │  • Initialize episode                                 │      │
│  │  • Load email dataset                                 │      │
│  │  • Return first observation                           │      │
│  └──────────────────────────────────────────────────────┘      │
│                           │                                      │
│                           ▼                                      │
│  ┌──────────────────────────────────────────────────────┐      │
│  │  step(action)                                         │      │
│  │  • Validate action format                             │      │
│  │  • Compute reward (deterministic)                     │      │
│  │  • Move to next email                                 │      │
│  │  • Return (obs, reward, done, info)                   │      │
│  └──────────────────────────────────────────────────────┘      │
│                           │                                      │
│                           ▼                                      │
│  ┌──────────────────────────────────────────────────────┐      │
│  │  state()                                              │      │
│  │  • Current observation                                │      │
│  │  • Episode progress                                   │      │
│  │  • Average reward                                     │      │
│  │  • Done status                                        │      │
│  └──────────────────────────────────────────────────────┘      │
└─────────────────────────────────────────────────────────────────┘
```

## AI Decision Flow

```
┌─────────────────────────────────────────────────────────────────┐
│                    Incoming Email                                │
│                                                                   │
│  • Subject: "URGENT: Production API is DOWN!"                   │
│  • Body: "Critical system failure..."                           │
│  • Customer Tier: Enterprise                                    │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│              STEP 1: Category Classification                     │
│                                                                   │
│  Pattern Matching:                                              │
│  • Billing patterns: 0 matches                                  │
│  • Technical patterns: 3 matches ✓                              │
│  • Account patterns: 0 matches                                  │
│  • Spam patterns: 0 matches                                     │
│                                                                   │
│  Decision: TECHNICAL                                            │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│              STEP 2: Sentiment Analysis                          │
│                                                                   │
│  Indicators:                                                     │
│  • Negative words: 2 (urgent, failure)                          │
│  • Positive words: 0                                            │
│  • Caps ratio: 0.35 (high)                                      │
│  • Exclamations: 2                                              │
│                                                                   │
│  Decision: NEGATIVE                                             │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│              STEP 3: Priority Calculation                        │
│                                                                   │
│  Base Priority:                                                  │
│  • Urgency keywords: 2 → Priority 4                             │
│                                                                   │
│  Adjustments:                                                    │
│  • Customer tier (Enterprise): +1                               │
│  • Negative sentiment: +1                                       │
│  • Final: 5 (clamped to max)                                    │
│                                                                   │
│  Decision: PRIORITY 5/5 (CRITICAL)                              │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│              STEP 4: Escalation Decision                         │
│                                                                   │
│  Rules Evaluation:                                               │
│  • Is spam? NO                                                  │
│  • Priority >= 5? YES ✓                                         │
│  • Enterprise + Priority >= 4? YES ✓                            │
│  • Negative + Priority >= 4? YES ✓                              │
│                                                                   │
│  Decision: ESCALATE TO HUMAN                                    │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│              STEP 5: Response Generation                         │
│                                                                   │
│  Context-Aware Template:                                        │
│  • Greeting: "Dear valued enterprise customer"                  │
│  • Acknowledgment: Apologetic tone (negative sentiment)         │
│  • Action: Escalation notice with timeline                      │
│  • Closing: Priority team signature                             │
│                                                                   │
│  Generated Response:                                            │
│  "Dear valued enterprise customer,                              │
│   We understand how frustrating technical issues can be...      │
│   This has been escalated to our specialized team...            │
│   Best regards, Priority Support Team"                          │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                    Final Decision                                │
│                                                                   │
│  • Category: technical                                          │
│  • Priority: 5/5                                                │
│  • Sentiment: negative                                          │
│  • Escalation: true                                             │
│  • Response: [Generated text]                                   │
│  • Confidence: 0.85                                             │
│  • Processing Time: 12ms                                        │
└─────────────────────────────────────────────────────────────────┘
```

## Reward Computation (OpenEnv)

### Task Level: HARD

```
┌─────────────────────────────────────────────────────────────────┐
│                    Ground Truth                                  │
│                                                                   │
│  • Category: technical                                          │
│  • Priority: 5                                                  │
│  • Expected Response Keywords: [urgent, investigate, team]      │
│  • Escalation: true                                             │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                    Agent Action                                  │
│                                                                   │
│  • Category: technical ✓                                        │
│  • Priority: 5 ✓                                                │
│  • Response: "We will investigate urgently with our team..."    │
│  • Escalation: true ✓                                           │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                 Reward Calculation                               │
│                                                                   │
│  Component 1 - Category (25%):                                  │
│    Match: technical == technical                                │
│    Score: 1.0 × 0.25 = 0.25                                     │
│                                                                   │
│  Component 2 - Priority (20%):                                  │
│    Error: |5 - 5| = 0                                           │
│    Score: (1.0 - 0/4) × 0.20 = 0.20                            │
│                                                                   │
│  Component 3 - Response (35%):                                  │
│    Keywords found: 3/3 (urgent, investigate, team)              │
│    Token overlap: 0.45                                          │
│    Similarity: (0.6 × 1.0) + (0.4 × 0.45) = 0.78               │
│    Score: 0.78 × 0.35 = 0.273                                   │
│                                                                   │
│  Component 4 - Escalation (20%):                                │
│    Match: true == true                                          │
│    Score: 1.0 × 0.20 = 0.20                                     │
│                                                                   │
│  Total Reward: 0.25 + 0.20 + 0.273 + 0.20 = 0.923              │
└─────────────────────────────────────────────────────────────────┘
```

## Data Flow

```
User Interaction
       │
       ▼
 Select Email ──────────────────┐
       │                        │
       ▼                        ▼
Choose Agent Type       View Email Details
  (AI/Baseline)                 │
       │                        │
       ▼                        │
Process Email ◄─────────────────┘
       │
       ├─── Category Classification
       │
       ├─── Sentiment Analysis
       │
       ├─── Priority Calculation
       │
       ├─── Escalation Decision
       │
       └─── Response Generation
                │
                ▼
         Store Decision
                │
                ▼
         Update UI
                │
                ├─── Email List (mark processed)
                ├─── Decision Panel (show results)
                └─── Stats Panel (update metrics)
```

## Technology Stack Layers

```
┌─────────────────────────────────────────────────────────────────┐
│                    Presentation Layer                            │
│  • React 18 (UI Components)                                     │
│  • Tailwind CSS (Styling)                                       │
│  • Lucide React (Icons)                                         │
│  • TypeScript (Type Safety)                                     │
└─────────────────────────────────────────────────────────────────┘
                              │
┌─────────────────────────────────────────────────────────────────┐
│                    Application Layer                             │
│  • Context API (State Management)                               │
│  • Custom Hooks (useEmail)                                      │
│  • Service Layer (AI Processing)                                │
└─────────────────────────────────────────────────────────────────┘
                              │
┌─────────────────────────────────────────────────────────────────┐
│                    Business Logic Layer                          │
│  • AI Agent (Intelligent Decision Making)                       │
│  • Baseline Agent (Rule-Based)                                  │
│  • Sentiment Analyzer                                           │
│  • Response Generator                                           │
└─────────────────────────────────────────────────────────────────┘
                              │
┌─────────────────────────────────────────────────────────────────┐
│                    Training/Evaluation Layer                     │
│  • OpenEnv Environment (Python)                                 │
│  • Reward Computation                                           │
│  • Ground Truth Comparison                                      │
└─────────────────────────────────────────────────────────────────┘
                              │
┌─────────────────────────────────────────────────────────────────┐
│                    Data Layer                                    │
│  • Email Dataset (50 realistic emails)                          │
│  • Ground Truth Labels                                          │
│  • Response Templates                                           │
└─────────────────────────────────────────────────────────────────┘
```

## Deployment Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                         Docker Container                         │
│                                                                   │
│  ┌──────────────────────────────────────────────────────┐      │
│  │              Frontend Build (Vite)                    │      │
│  │                                                        │      │
│  │  • Compiled React app                                 │      │
│  │  • Optimized assets                                   │      │
│  │  • Service workers                                    │      │
│  └──────────────────────────────────────────────────────┘      │
│                           │                                      │
│  ┌──────────────────────────────────────────────────────┐      │
│  │          Node.js Preview Server                       │      │
│  │                                                        │      │
│  │  • Serves static files                                │      │
│  │  • Port: 3000                                         │      │
│  └──────────────────────────────────────────────────────┘      │
│                           │                                      │
│  ┌──────────────────────────────────────────────────────┐      │
│  │          Python Environment (Optional)                │      │
│  │                                                        │      │
│  │  • OpenEnv environment                                │      │
│  │  • Training scripts                                   │      │
│  │  • Evaluation tools                                   │      │
│  └──────────────────────────────────────────────────────┘      │
└─────────────────────────────────────────────────────────────────┘
```

## Scalability Considerations

### Horizontal Scaling
- Stateless UI components
- Service layer can be extracted to API
- Database-backed storage for production

### Performance Optimization
- Response caching
- Lazy loading of email list
- Virtual scrolling for large datasets
- Memoized computations

### Production Enhancements
- Real IMAP/SMTP integration
- Webhook support
- Queue-based processing
- Rate limiting
- Authentication & authorization
- Audit logging

## Security Architecture

```
Browser ──[HTTPS]──> Frontend (React)
                           │
                           ├─ Input Validation
                           ├─ XSS Prevention (React)
                           ├─ CSRF Protection
                           │
                           ▼
                    Service Layer
                           │
                           ├─ Sanitization
                           ├─ Rate Limiting
                           ├─ Error Handling
                           │
                           ▼
                     Data Layer
                           │
                           ├─ Parameterized Queries
                           ├─ Access Control
                           └─ Encryption at Rest
```

This architecture ensures:
- **Modularity**: Easy to extend and modify
- **Testability**: Each layer can be tested independently
- **Scalability**: Can handle increased load
- **Maintainability**: Clear separation of concerns
- **Production-Ready**: Built for real-world deployment
