"""
OpenEnv-compliant Email Triage Environment
Implements reset(), step(), and state() methods for AI training/evaluation
"""

import json
import time
from datetime import datetime
from typing import Dict, Tuple, Any, Optional
from dataclasses import dataclass


@dataclass
class EmailObservation:
    """Email observation structure"""
    email_id: str
    subject: str
    body: str
    customer_tier: str
    received_at: str


@dataclass
class Action:
    """Action structure"""
    category: str
    priority: int
    response: str
    escalation: bool


@dataclass
class GroundTruth:
    """Ground truth labels for evaluation"""
    category: str
    priority: int
    expected_response: str
    escalation: bool
    keywords: list


class EmailTriageEnv:
    """
    OpenEnv Environment for Email Triage System

    Observation Space:
        - email_id: str
        - subject: str
        - body: str
        - customer_tier: str (free, premium, enterprise)
        - received_at: timestamp

    Action Space:
        - category: str (billing, technical, account, spam, other)
        - priority: int (1-5)
        - response: str
        - escalation: bool

    Task Levels:
        - EASY: Category classification only
        - MEDIUM: Category + Priority
        - HARD: Full pipeline (category, priority, response, escalation)
    """

    def __init__(self, task_level: str = "hard"):
        """
        Initialize environment

        Args:
            task_level: "easy", "medium", or "hard"
        """
        self.task_level = task_level.lower()
        self.current_index = 0
        self.emails = []
        self.ground_truths = []
        self.done = False
        self.episode_rewards = []
        self.start_time = None

        self._load_dataset()

    def _load_dataset(self):
        """Load email dataset with ground truth labels"""
        from .dataset import get_email_dataset
        self.emails, self.ground_truths = get_email_dataset()

    def reset(self) -> EmailObservation:
        """
        Reset environment to initial state

        Returns:
            Initial observation
        """
        self.current_index = 0
        self.done = False
        self.episode_rewards = []
        self.start_time = time.time()

        return self._get_observation()

    def step(self, action: Dict[str, Any]) -> Tuple[EmailObservation, float, bool, Dict]:
        """
        Execute action and compute reward

        Args:
            action: Dictionary with keys: category, priority, response, escalation

        Returns:
            observation: Next observation
            reward: Reward score (0.0 to 1.0)
            done: Whether episode is complete
            info: Additional information
        """
        if self.done:
            raise RuntimeError("Episode is done. Call reset().")

        # Parse action
        action_obj = Action(
            category=action.get('category', '').lower(),
            priority=int(action.get('priority', 3)),
            response=action.get('response', ''),
            escalation=bool(action.get('escalation', False))
        )

        # Compute reward
        reward, info = self._compute_reward(action_obj)
        self.episode_rewards.append(reward)

        # Move to next email
        self.current_index += 1

        # Check if done
        if self.current_index >= len(self.emails):
            self.done = True
            info['episode_reward'] = sum(self.episode_rewards) / len(self.episode_rewards)
            info['total_time'] = time.time() - self.start_time

        # Get next observation
        observation = self._get_observation() if not self.done else None

        return observation, reward, self.done, info

    def state(self) -> Dict[str, Any]:
        """
        Get current environment state

        Returns:
            State dictionary
        """
        current_obs = self._get_observation()

        return {
            'current_observation': current_obs.__dict__ if current_obs else None,
            'current_index': self.current_index,
            'total_emails': len(self.emails),
            'done': self.done,
            'task_level': self.task_level,
            'episode_rewards': self.episode_rewards,
            'average_reward': sum(self.episode_rewards) / len(self.episode_rewards) if self.episode_rewards else 0.0
        }

    def _get_observation(self) -> Optional[EmailObservation]:
        """Get current observation"""
        if self.current_index >= len(self.emails):
            return None

        email = self.emails[self.current_index]
        return EmailObservation(**email)

    def _compute_reward(self, action: Action) -> Tuple[float, Dict]:
        """
        Compute reward based on task level (DETERMINISTIC)

        Returns:
            reward: float between 0.0 and 1.0
            info: dict with detailed metrics
        """
        gt = self.ground_truths[self.current_index]
        info = {}

        if self.task_level == "easy":
            # Only category matters
            category_correct = (action.category == gt.category)
            reward = 1.0 if category_correct else 0.0
            info['category_correct'] = category_correct

        elif self.task_level == "medium":
            # Category (0.5) + Priority (0.5)
            category_correct = (action.category == gt.category)
            priority_error = abs(action.priority - gt.priority)
            priority_score = max(0, 1.0 - (priority_error / 4.0))  # Normalize to 0-1

            reward = (0.5 if category_correct else 0.0) + (0.5 * priority_score)
            info['category_correct'] = category_correct
            info['priority_error'] = priority_error
            info['priority_score'] = priority_score

        else:  # hard
            # Category (0.25) + Priority (0.2) + Response (0.35) + Escalation (0.2)
            category_correct = (action.category == gt.category)
            priority_error = abs(action.priority - gt.priority)
            priority_score = max(0, 1.0 - (priority_error / 4.0))

            # Response similarity (keyword overlap)
            response_similarity = self._compute_response_similarity(
                action.response,
                gt.expected_response,
                gt.keywords
            )

            escalation_correct = (action.escalation == gt.escalation)

            # Compute total reward
            reward = (
                (0.25 if category_correct else 0.0) +
                (0.2 * priority_score) +
                (0.35 * response_similarity) +
                (0.2 if escalation_correct else 0.0)
            )

            # SLA penalty (if response too slow, not applicable in simulation)
            # Can be extended for real-time systems

            info['category_correct'] = category_correct
            info['priority_error'] = priority_error
            info['priority_score'] = priority_score
            info['response_similarity'] = response_similarity
            info['escalation_correct'] = escalation_correct

        # Ensure reward is between 0 and 1
        reward = max(0.0, min(1.0, reward))
        info['reward'] = reward

        return reward, info

    def _compute_response_similarity(self, generated: str, expected: str, keywords: list) -> float:
        """
        Compute response similarity using deterministic keyword matching

        Args:
            generated: Generated response text
            expected: Expected response text
            keywords: Important keywords that should appear

        Returns:
            Similarity score between 0.0 and 1.0
        """
        if not generated:
            return 0.0

        generated_lower = generated.lower()
        expected_lower = expected.lower()

        # Method 1: Keyword coverage (60% weight)
        keyword_hits = sum(1 for kw in keywords if kw.lower() in generated_lower)
        keyword_score = keyword_hits / len(keywords) if keywords else 0.0

        # Method 2: Token overlap (40% weight)
        generated_tokens = set(generated_lower.split())
        expected_tokens = set(expected_lower.split())

        if not expected_tokens:
            token_score = 0.0
        else:
            overlap = len(generated_tokens & expected_tokens)
            token_score = overlap / len(expected_tokens)

        # Combined score
        similarity = (0.6 * keyword_score) + (0.4 * token_score)

        return min(1.0, similarity)

    def get_ground_truth(self, index: int = None) -> GroundTruth:
        """Get ground truth for specific email (useful for evaluation)"""
        idx = index if index is not None else self.current_index
        return self.ground_truths[idx]

    def render(self, mode='human'):
        """Render environment state (optional)"""
        state = self.state()
        print(f"\n{'='*60}")
        print(f"Email Triage Environment - {self.task_level.upper()} Mode")
        print(f"{'='*60}")
        print(f"Progress: {state['current_index']}/{state['total_emails']}")
        print(f"Average Reward: {state['average_reward']:.3f}")

        if state['current_observation']:
            obs = state['current_observation']
            print(f"\nCurrent Email:")
            print(f"  ID: {obs['email_id']}")
            print(f"  Subject: {obs['subject']}")
            print(f"  Customer: {obs['customer_tier']}")
            print(f"  Body: {obs['body'][:100]}...")

        print(f"{'='*60}\n")


def test_environment():
    """Test the environment with a simple agent"""
    env = EmailTriageEnv(task_level="hard")

    # Reset environment
    obs = env.reset()
    print(f"Initial observation: {obs}")

    # Run through all emails
    total_reward = 0
    count = 0

    while not env.done:
        # Simple dummy action
        action = {
            'category': 'technical',
            'priority': 3,
            'response': 'Thank you for contacting us. We will look into this issue.',
            'escalation': False
        }

        obs, reward, done, info = env.step(action)
        total_reward += reward
        count += 1

        print(f"Step {count}: Reward = {reward:.3f}, Info = {info}")

    print(f"\nEpisode complete!")
    print(f"Average reward: {total_reward / count:.3f}")
    print(f"Final state: {env.state()}")


if __name__ == "__main__":
    test_environment()
