"""
Realistic Email Dataset with Ground Truth Labels
Contains 50 diverse customer support emails
"""

from datetime import datetime, timedelta
import random


def get_email_dataset():
    """
    Returns email dataset with ground truth labels

    Returns:
        emails: List of email dictionaries
        ground_truths: List of ground truth dictionaries
    """

    emails = [
        # BILLING ISSUES (10 emails)
        {
            "email_id": "e001",
            "subject": "Urgent: Double charged on my credit card!",
            "body": "I just noticed I was charged TWICE for my subscription this month. This is unacceptable! I need this fixed immediately or I'm canceling my account. My card ending in 4532 shows two charges of $49.99 each. Please refund one immediately.",
            "customer_tier": "premium",
            "received_at": datetime.now().isoformat()
        },
        {
            "email_id": "e002",
            "subject": "Question about invoice #12847",
            "body": "Hello, I received invoice #12847 but I don't understand what the 'platform fee' charge is for. Could you please explain this? Also, is there a way to get an itemized breakdown? Thanks!",
            "customer_tier": "enterprise",
            "received_at": datetime.now().isoformat()
        },
        {
            "email_id": "e003",
            "subject": "Payment failed - need help",
            "body": "Hi, my payment keeps failing when I try to upgrade to premium. I've tried three different cards and none work. The error message says 'Payment processing error'. Can you help?",
            "customer_tier": "free",
            "received_at": datetime.now().isoformat()
        },
        {
            "email_id": "e004",
            "subject": "Refund request",
            "body": "I'd like to request a refund for the annual plan I purchased yesterday. I realized the features don't match what I need for my business. Order number: ORD-9482.",
            "customer_tier": "premium",
            "received_at": datetime.now().isoformat()
        },
        {
            "email_id": "e005",
            "subject": "Billing cycle change",
            "body": "Is it possible to change my billing cycle from monthly to annual? I'd like to take advantage of the annual discount. Please let me know the steps.",
            "customer_tier": "premium",
            "received_at": datetime.now().isoformat()
        },
        {
            "email_id": "e006",
            "subject": "CHARGED AFTER CANCELLATION!!!",
            "body": "I CANCELLED my subscription THREE WEEKS AGO and you STILL charged me today! This is THEFT! I want my money back NOW and I'm reporting this to my credit card company. This is completely unacceptable!",
            "customer_tier": "free",
            "received_at": datetime.now().isoformat()
        },
        {
            "email_id": "e007",
            "subject": "Tax exemption certificate",
            "body": "Our organization is tax-exempt. Please find attached our tax exemption certificate. We need future invoices to reflect this status. Our account ID is ACCT-ENT-8472.",
            "customer_tier": "enterprise",
            "received_at": datetime.now().isoformat()
        },
        {
            "email_id": "e008",
            "subject": "Invoice not received",
            "body": "I haven't received my invoice for this month yet. Usually it arrives by the 5th. Could you please resend it to this email address?",
            "customer_tier": "premium",
            "received_at": datetime.now().isoformat()
        },
        {
            "email_id": "e009",
            "subject": "Pricing inquiry for team plan",
            "body": "We're considering upgrading to the team plan for 25 users. What would be the total monthly cost? Do you offer any discounts for annual commitment?",
            "customer_tier": "free",
            "received_at": datetime.now().isoformat()
        },
        {
            "email_id": "e010",
            "subject": "Suspicious charge on account",
            "body": "I see a charge of $299 on my account that I don't recognize. I never authorized this purchase. Please investigate and reverse this charge immediately.",
            "customer_tier": "enterprise",
            "received_at": datetime.now().isoformat()
        },

        # TECHNICAL ISSUES (15 emails)
        {
            "email_id": "e011",
            "subject": "App crashes on startup",
            "body": "The mobile app crashes immediately after I open it. I've tried uninstalling and reinstalling but the problem persists. I'm using iPhone 14 Pro with iOS 17.2. Please help!",
            "customer_tier": "premium",
            "received_at": datetime.now().isoformat()
        },
        {
            "email_id": "e012",
            "subject": "API integration not working",
            "body": "We're trying to integrate your API but keep getting 401 errors. We've double-checked our API keys and they appear correct. Documentation says to use Bearer token but that's not working. Need urgent help as this is blocking our production deployment.",
            "customer_tier": "enterprise",
            "received_at": datetime.now().isoformat()
        },
        {
            "email_id": "e013",
            "subject": "Data export feature broken",
            "body": "When I try to export my data to CSV, I get an error message 'Export failed'. This has been happening for the past 3 days. I need this data for my quarterly report. Please fix ASAP.",
            "customer_tier": "premium",
            "received_at": datetime.now().isoformat()
        },
        {
            "email_id": "e014",
            "subject": "Slow loading times",
            "body": "The dashboard has been extremely slow to load for the past week. It takes 30+ seconds to display data. This is affecting our team's productivity. Is there a server issue?",
            "customer_tier": "enterprise",
            "received_at": datetime.now().isoformat()
        },
        {
            "email_id": "e015",
            "subject": "Feature request - dark mode",
            "body": "Would love to see a dark mode option added to the app. Many of us work late hours and the bright interface is hard on the eyes. Thanks for considering!",
            "customer_tier": "free",
            "received_at": datetime.now().isoformat()
        },
        {
            "email_id": "e016",
            "subject": "CRITICAL: Data loss after update",
            "body": "After the update this morning, ALL of our project data is GONE! This is a critical issue affecting our entire team of 50 people. We need this restored immediately or we're facing serious business consequences!",
            "customer_tier": "enterprise",
            "received_at": datetime.now().isoformat()
        },
        {
            "email_id": "e017",
            "subject": "Browser compatibility issue",
            "body": "The web app doesn't work properly in Firefox. Several buttons don't respond to clicks. Works fine in Chrome though. Can you add Firefox support?",
            "customer_tier": "free",
            "received_at": datetime.now().isoformat()
        },
        {
            "email_id": "e018",
            "subject": "Webhook not triggering",
            "body": "Our webhook endpoint hasn't received any events for the past 2 hours. We've checked our server logs and our endpoint is working fine. Is there an issue on your side?",
            "customer_tier": "enterprise",
            "received_at": datetime.now().isoformat()
        },
        {
            "email_id": "e019",
            "subject": "Email notifications not working",
            "body": "I've enabled email notifications in settings but I'm not receiving any emails. I've checked my spam folder too. My email is correct in the profile.",
            "customer_tier": "premium",
            "received_at": datetime.now().isoformat()
        },
        {
            "email_id": "e020",
            "subject": "Mobile app battery drain",
            "body": "The mobile app is draining my battery very quickly. Even when running in the background. Is this a known issue?",
            "customer_tier": "free",
            "received_at": datetime.now().isoformat()
        },
        {
            "email_id": "e021",
            "subject": "Search function not returning results",
            "body": "When I search for specific items, I get zero results even though I know they exist. The search worked fine last week. Using version 2.4.1.",
            "customer_tier": "premium",
            "received_at": datetime.now().isoformat()
        },
        {
            "email_id": "e022",
            "subject": "File upload fails for large files",
            "body": "Cannot upload files larger than 10MB. The upload starts but then fails with 'Network error'. Smaller files work fine. Need to upload files up to 50MB.",
            "customer_tier": "premium",
            "received_at": datetime.now().isoformat()
        },
        {
            "email_id": "e023",
            "subject": "Sync issues between devices",
            "body": "Changes I make on my desktop don't sync to my mobile app. They used to sync instantly but now there's a delay of hours or it doesn't sync at all.",
            "customer_tier": "premium",
            "received_at": datetime.now().isoformat()
        },
        {
            "email_id": "e024",
            "subject": "Security concern - SSL certificate",
            "body": "My browser is showing a security warning about your SSL certificate. It says the certificate is invalid. This is concerning for our enterprise security policies.",
            "customer_tier": "enterprise",
            "received_at": datetime.now().isoformat()
        },
        {
            "email_id": "e025",
            "subject": "Dashboard widget not updating",
            "body": "The analytics widget on my dashboard shows data from last week and won't refresh. I've tried clicking refresh multiple times.",
            "customer_tier": "premium",
            "received_at": datetime.now().isoformat()
        },

        # ACCOUNT ISSUES (10 emails)
        {
            "email_id": "e026",
            "subject": "Can't log in - forgot password",
            "body": "I forgot my password and the reset link doesn't seem to be working. I click 'Reset Password' but never receive an email. Can you help me regain access to my account?",
            "customer_tier": "free",
            "received_at": datetime.now().isoformat()
        },
        {
            "email_id": "e027",
            "subject": "Account locked after failed login attempts",
            "body": "My account has been locked due to failed login attempts. I was trying different passwords but now I'm completely locked out. Please unlock my account - this is urgent!",
            "customer_tier": "premium",
            "received_at": datetime.now().isoformat()
        },
        {
            "email_id": "e028",
            "subject": "Change email address on account",
            "body": "I need to update the email address associated with my account. My old email (john@oldcompany.com) is no longer active. New email is john@newcompany.com.",
            "customer_tier": "premium",
            "received_at": datetime.now().isoformat()
        },
        {
            "email_id": "e029",
            "subject": "Delete my account and data",
            "body": "I would like to permanently delete my account and all associated data per GDPR requirements. Please confirm when this is complete.",
            "customer_tier": "free",
            "received_at": datetime.now().isoformat()
        },
        {
            "email_id": "e030",
            "subject": "Add users to team account",
            "body": "We need to add 5 new team members to our enterprise account. What's the process for this? Do they need to create accounts first or do we send invites?",
            "customer_tier": "enterprise",
            "received_at": datetime.now().isoformat()
        },
        {
            "email_id": "e031",
            "subject": "Two-factor authentication issue",
            "body": "I lost my phone with my authenticator app. Now I can't log in because I don't have access to my 2FA codes. Please help me recover my account!",
            "customer_tier": "premium",
            "received_at": datetime.now().isoformat()
        },
        {
            "email_id": "e032",
            "subject": "Suspicious activity on account",
            "body": "I just received a notification about activity from an IP address I don't recognize in Russia. I haven't traveled there. Has my account been compromised?",
            "customer_tier": "enterprise",
            "received_at": datetime.now().isoformat()
        },
        {
            "email_id": "e033",
            "subject": "Transfer account ownership",
            "body": "I'm leaving the company and need to transfer account ownership to my replacement. What's the process for this? Account ID: ACCT-9847.",
            "customer_tier": "enterprise",
            "received_at": datetime.now().isoformat()
        },
        {
            "email_id": "e034",
            "subject": "Update company information",
            "body": "Our company has been acquired and we need to update our billing information and company name on the account. Please advise on the procedure.",
            "customer_tier": "enterprise",
            "received_at": datetime.now().isoformat()
        },
        {
            "email_id": "e035",
            "subject": "Downgrade subscription",
            "body": "I'd like to downgrade from premium to the free plan. Will I lose access to my data? What happens to my projects?",
            "customer_tier": "premium",
            "received_at": datetime.now().isoformat()
        },

        # SPAM (5 emails)
        {
            "email_id": "e036",
            "subject": "🎉 You've won $1,000,000! Claim now!",
            "body": "Congratulations!!! You have been selected as our lucky winner! Click here to claim your prize of ONE MILLION DOLLARS. Act fast, this offer expires in 24 hours! Click now: http://suspicious-link.com",
            "customer_tier": "free",
            "received_at": datetime.now().isoformat()
        },
        {
            "email_id": "e037",
            "subject": "Increase your ROI by 500% with our amazing tool",
            "body": "Dear Sir/Madam, Are you tired of low profits? Our revolutionary tool will increase your ROI by 500% GUARANTEED! Buy now for only $99! Limited time offer! Click here to order now!",
            "customer_tier": "free",
            "received_at": datetime.now().isoformat()
        },
        {
            "email_id": "e038",
            "subject": "Re: Re: Re: Fwd: Check this out!!!",
            "body": "You won't believe what I found!!! Click this link to see amazing photos! http://definitely-not-malware.com/photos.exe",
            "customer_tier": "free",
            "received_at": datetime.now().isoformat()
        },
        {
            "email_id": "e039",
            "subject": "Urgent: Your account will be suspended",
            "body": "This is an automated message. Your account will be suspended in 24 hours due to suspicious activity. To prevent suspension, click here and verify your credit card information immediately. This is not a phishing attempt.",
            "customer_tier": "free",
            "received_at": datetime.now().isoformat()
        },
        {
            "email_id": "e040",
            "subject": "Make money from home - no experience needed!",
            "body": "Work from home and earn $5000 per week! No experience necessary! Just send us $199 for our training package and start earning immediately! Limited spots available!",
            "customer_tier": "free",
            "received_at": datetime.now().isoformat()
        },

        # OTHER / GENERAL (10 emails)
        {
            "email_id": "e041",
            "subject": "Partnership opportunity",
            "body": "Hello, I represent a large corporation interested in partnering with your company. We'd like to discuss integration opportunities. Please let me know who I should speak with.",
            "customer_tier": "free",
            "received_at": datetime.now().isoformat()
        },
        {
            "email_id": "e042",
            "subject": "Product feedback",
            "body": "I've been using your product for 6 months and overall it's great! Just wanted to share some feedback on features that could be improved. The reporting module could use more customization options.",
            "customer_tier": "premium",
            "received_at": datetime.now().isoformat()
        },
        {
            "email_id": "e043",
            "subject": "Documentation question",
            "body": "Where can I find documentation on the REST API endpoints? The link in the dashboard returns a 404 error.",
            "customer_tier": "free",
            "received_at": datetime.now().isoformat()
        },
        {
            "email_id": "e044",
            "subject": "Training materials request",
            "body": "We're onboarding 20 new employees next month. Do you have any training materials or videos we can use to get them up to speed quickly?",
            "customer_tier": "enterprise",
            "received_at": datetime.now().isoformat()
        },
        {
            "email_id": "e045",
            "subject": "Compliance questionnaire",
            "body": "Our compliance team needs you to fill out the attached security questionnaire for our vendor assessment process. Please return it within 2 weeks.",
            "customer_tier": "enterprise",
            "received_at": datetime.now().isoformat()
        },
        {
            "email_id": "e046",
            "subject": "Speaking opportunity at our conference",
            "body": "We're organizing a tech conference and would love to have someone from your team speak about your product. The event is in Boston this November. Interested?",
            "customer_tier": "free",
            "received_at": datetime.now().isoformat()
        },
        {
            "email_id": "e047",
            "subject": "Case study request",
            "body": "We've had great success with your platform and would be happy to participate in a case study. Let me know if you're interested and what the process would be.",
            "customer_tier": "enterprise",
            "received_at": datetime.now().isoformat()
        },
        {
            "email_id": "e048",
            "subject": "Media inquiry",
            "body": "I'm a journalist writing an article about customer support automation. I'd like to interview someone from your team about your approach and technology. Are you available?",
            "customer_tier": "free",
            "received_at": datetime.now().isoformat()
        },
        {
            "email_id": "e049",
            "subject": "Thank you!",
            "body": "Just wanted to send a quick thank you to your support team. Sarah helped me resolve my issue in under 5 minutes. Excellent customer service!",
            "customer_tier": "premium",
            "received_at": datetime.now().isoformat()
        },
        {
            "email_id": "e050",
            "subject": "General inquiry",
            "body": "Hi, I'm considering your product for my small business. Can you tell me more about the differences between the premium and enterprise plans?",
            "customer_tier": "free",
            "received_at": datetime.now().isoformat()
        }
    ]

    ground_truths = [
        # Billing (e001-e010)
        {"category": "billing", "priority": 5, "escalation": True, "keywords": ["refund", "double", "charge", "immediate", "review"], "expected_response": "We sincerely apologize for the double charge. This is being escalated to our billing team for immediate review and refund processing within 24 hours."},
        {"category": "billing", "priority": 2, "escalation": False, "keywords": ["invoice", "breakdown", "platform fee", "explain"], "expected_response": "Thank you for reaching out. The platform fee covers infrastructure costs. I'll send you a detailed itemized breakdown of invoice #12847 shortly."},
        {"category": "billing", "priority": 3, "escalation": False, "keywords": ["payment", "failed", "upgrade", "help"], "expected_response": "I'm sorry you're experiencing payment issues. This could be due to card verification or bank restrictions. Let's try updating your payment method or contact your bank to authorize the transaction."},
        {"category": "billing", "priority": 3, "escalation": False, "keywords": ["refund", "annual", "request", "process"], "expected_response": "I've initiated your refund request for order ORD-9482. Our billing team will process this within 5-7 business days and you'll receive confirmation via email."},
        {"category": "billing", "priority": 2, "escalation": False, "keywords": ["billing cycle", "annual", "discount", "change"], "expected_response": "Yes, you can switch to annual billing. You'll save 20% with the annual plan. I can help you make this change immediately from your account settings."},
        {"category": "billing", "priority": 5, "escalation": True, "keywords": ["cancelled", "charged", "refund", "urgent"], "expected_response": "I sincerely apologize for this error. This is being escalated immediately to our billing team for investigation and refund. We take cancellation requests very seriously."},
        {"category": "billing", "priority": 3, "escalation": False, "keywords": ["tax", "exempt", "certificate", "invoice"], "expected_response": "Thank you for providing your tax exemption certificate. I've updated your account (ACCT-ENT-8472) and all future invoices will reflect your tax-exempt status."},
        {"category": "billing", "priority": 2, "escalation": False, "keywords": ["invoice", "resend", "email"], "expected_response": "I've resent your invoice to this email address. You should receive it within a few minutes. If you don't see it, please check your spam folder."},
        {"category": "billing", "priority": 2, "escalation": False, "keywords": ["pricing", "team", "discount", "quote"], "expected_response": "For 25 users on the team plan, the monthly cost would be $625. With an annual commitment, you'd save 20% bringing it to $6000/year ($500/month). I can send you a detailed quote."},
        {"category": "billing", "priority": 5, "escalation": True, "keywords": ["suspicious", "charge", "unauthorized", "investigate"], "expected_response": "This is a serious concern. I'm escalating this to our security and billing teams immediately to investigate the unauthorized $299 charge. We'll resolve this within 24 hours."},

        # Technical (e011-e025)
        {"category": "technical", "priority": 4, "escalation": True, "keywords": ["crash", "mobile", "iOS", "fix"], "expected_response": "I'm sorry you're experiencing crashes. This is a known issue with iOS 17.2 that our engineering team is actively working on. I'm escalating this to get you a hotfix as soon as possible."},
        {"category": "technical", "priority": 5, "escalation": True, "keywords": ["API", "401", "production", "urgent"], "expected_response": "API authentication issues blocking production are critical. I'm escalating this to our engineering team immediately. In the meantime, please verify your API key format matches: 'Bearer sk-xxx'. We'll have someone contact you within the hour."},
        {"category": "technical", "priority": 4, "escalation": False, "keywords": ["export", "CSV", "error", "fix"], "expected_response": "I'm sorry the CSV export is failing. Our engineering team has been notified of this issue. As a workaround, you can use the JSON export option while we work on fixing the CSV functionality."},
        {"category": "technical", "priority": 4, "escalation": True, "keywords": ["slow", "performance", "server", "dashboard"], "expected_response": "Persistent slow loading for enterprise customers is a priority issue. I'm escalating this to our infrastructure team to investigate potential server issues affecting your dashboard performance."},
        {"category": "technical", "priority": 1, "escalation": False, "keywords": ["feature", "request", "dark mode"], "expected_response": "Thank you for the suggestion! Dark mode is on our roadmap. I've added your vote to this feature request. We'll notify you when it's available."},
        {"category": "technical", "priority": 5, "escalation": True, "keywords": ["data loss", "critical", "restore", "urgent"], "expected_response": "Data loss is our highest priority. I'm escalating this IMMEDIATELY to our engineering team for emergency restoration from backups. Someone will contact you within 15 minutes. We apologize for this critical issue."},
        {"category": "technical", "priority": 2, "escalation": False, "keywords": ["Firefox", "compatibility", "browser"], "expected_response": "Thank you for reporting the Firefox compatibility issue. We're working on improving cross-browser support. As a temporary workaround, please use Chrome while we address the Firefox-specific issues."},
        {"category": "technical", "priority": 5, "escalation": True, "keywords": ["webhook", "not triggering", "urgent", "investigate"], "expected_response": "Webhook failures affecting enterprise operations are critical. I'm escalating this to our engineering team immediately to investigate the event delivery system. We'll have an update within 30 minutes."},
        {"category": "technical", "priority": 3, "escalation": False, "keywords": ["email", "notifications", "not receiving"], "expected_response": "Let's troubleshoot your email notifications. Please verify your email settings and whitelist our domain (notifications@ourapp.com). If the issue persists, we'll check our notification service logs."},
        {"category": "technical", "priority": 2, "escalation": False, "keywords": ["battery", "drain", "mobile", "background"], "expected_response": "Thank you for reporting the battery drain issue. Try disabling background sync in the app settings. We're also working on optimizing battery usage in our next mobile update."},
        {"category": "technical", "priority": 3, "escalation": False, "keywords": ["search", "not working", "results", "fix"], "expected_response": "Search not returning expected results is concerning. Try clearing your app cache first. If that doesn't help, we may need to reindex your data. I can assist with this process."},
        {"category": "technical", "priority": 3, "escalation": False, "keywords": ["file", "upload", "large", "limit"], "expected_response": "File upload limits depend on your plan tier. Premium accounts support up to 50MB per file. Please verify your plan status, and if you're on premium, we'll investigate the upload failure."},
        {"category": "technical", "priority": 3, "escalation": False, "keywords": ["sync", "devices", "delay", "not working"], "expected_response": "Sync delays can be frustrating. Try forcing a manual sync from the settings menu on both devices. If the issue persists, we may need to reset your sync token."},
        {"category": "technical", "priority": 5, "escalation": True, "keywords": ["SSL", "certificate", "security", "invalid"], "expected_response": "SSL certificate issues affecting enterprise security are critical. I'm escalating this to our security team immediately for investigation. This should not be happening and we'll resolve it urgently."},
        {"category": "technical", "priority": 3, "escalation": False, "keywords": ["dashboard", "widget", "not updating", "refresh"], "expected_response": "Try clearing your browser cache and hard-refreshing the page. If the widget still doesn't update, there may be a caching issue on our end that we'll need to investigate."},

        # Account (e026-e035)
        {"category": "account", "priority": 3, "escalation": False, "keywords": ["password", "reset", "email", "access"], "expected_response": "Let me help you reset your password. I'll manually trigger a password reset email from our end. Please check your spam folder and verify the email address on your account is correct."},
        {"category": "account", "priority": 4, "escalation": False, "keywords": ["locked", "unlock", "access", "urgent"], "expected_response": "I can unlock your account immediately for security verification. I've reset the lockout counter. Please try logging in again with your correct password."},
        {"category": "account", "priority": 3, "escalation": False, "keywords": ["email", "change", "update", "verify"], "expected_response": "To update your email address, I'll need to verify your identity first. I'm sending a verification code to your current email. Once verified, we can update to john@newcompany.com."},
        {"category": "account", "priority": 3, "escalation": False, "keywords": ["delete", "account", "GDPR", "data"], "expected_response": "I've initiated the account deletion process per GDPR requirements. Your account and all associated data will be permanently deleted within 30 days. You'll receive confirmation once complete."},
        {"category": "account", "priority": 2, "escalation": False, "keywords": ["add users", "team", "invite", "enterprise"], "expected_response": "To add team members, go to Settings > Team Management. You can send email invites directly from there. The new members will receive invitation links to join your enterprise account."},
        {"category": "account", "priority": 4, "escalation": False, "keywords": ["2FA", "lost phone", "recovery", "access"], "expected_response": "Losing access to 2FA is challenging but we can help. I'll need to verify your identity using alternative methods. Please provide your account email and answer your security questions to proceed with 2FA reset."},
        {"category": "account", "priority": 5, "escalation": True, "keywords": ["suspicious", "activity", "compromised", "security"], "expected_response": "Suspicious activity from unknown locations is a serious security concern. I'm escalating this immediately to our security team. As a precaution, I recommend changing your password immediately. We'll investigate the Russia IP address access."},
        {"category": "account", "priority": 3, "escalation": False, "keywords": ["transfer", "ownership", "account"], "expected_response": "To transfer account ownership for ACCT-9847, both you and your replacement will need to verify the transfer. I'll send you the transfer request form. This typically takes 2-3 business days to complete."},
        {"category": "account", "priority": 3, "escalation": False, "keywords": ["update", "company", "information", "billing"], "expected_response": "Congratulations on the acquisition! To update your company information, please provide the new company name and updated billing details. We'll update your account and all future invoices accordingly."},
        {"category": "account", "priority": 2, "escalation": False, "keywords": ["downgrade", "free", "data", "projects"], "expected_response": "When downgrading to free, your data remains accessible but some premium features will be disabled. Your projects are safe. You can downgrade from Settings > Subscription."},

        # Spam (e036-e040)
        {"category": "spam", "priority": 1, "escalation": False, "keywords": ["spam", "phishing", "suspicious"], "expected_response": "This email has been identified as spam and filtered accordingly."},
        {"category": "spam", "priority": 1, "escalation": False, "keywords": ["spam", "marketing", "unsolicited"], "expected_response": "This email has been identified as spam and filtered accordingly."},
        {"category": "spam", "priority": 1, "escalation": False, "keywords": ["spam", "malware", "suspicious"], "expected_response": "This email has been identified as spam and filtered accordingly."},
        {"category": "spam", "priority": 1, "escalation": False, "keywords": ["spam", "phishing", "fake"], "expected_response": "This email has been identified as spam and filtered accordingly."},
        {"category": "spam", "priority": 1, "escalation": False, "keywords": ["spam", "scam", "money"], "expected_response": "This email has been identified as spam and filtered accordingly."},

        # Other (e041-e050)
        {"category": "other", "priority": 2, "escalation": False, "keywords": ["partnership", "business", "contact", "discuss"], "expected_response": "Thank you for your interest in partnering with us. I've forwarded your inquiry to our business development team. They'll reach out to discuss partnership opportunities."},
        {"category": "other", "priority": 2, "escalation": False, "keywords": ["feedback", "product", "improvement", "feature"], "expected_response": "Thank you for the positive feedback and suggestions! We really appreciate customers who take time to share their experience. I've forwarded your reporting module feedback to our product team."},
        {"category": "other", "priority": 2, "escalation": False, "keywords": ["documentation", "API", "link", "404"], "expected_response": "Sorry about the broken documentation link. The correct API documentation can be found at: docs.ourapp.com/api. I'll also get that broken link fixed. Thank you for reporting it!"},
        {"category": "other", "priority": 2, "escalation": False, "keywords": ["training", "materials", "onboarding", "videos"], "expected_response": "We have comprehensive training materials available! I'll send you links to our video tutorials, quick start guides, and onboarding documentation perfect for your 20 new employees."},
        {"category": "other", "priority": 3, "escalation": False, "keywords": ["compliance", "questionnaire", "security", "vendor"], "expected_response": "We're happy to complete your compliance questionnaire. Our security team will fill this out and return it within one week. Thank you for the 2-week timeline."},
        {"category": "other", "priority": 2, "escalation": False, "keywords": ["speaking", "conference", "event", "presentation"], "expected_response": "Thank you for the speaking invitation! This sounds like a great opportunity. I've forwarded your request to our marketing team who handles conference appearances. They'll be in touch soon."},
        {"category": "other", "priority": 2, "escalation": False, "keywords": ["case study", "success", "participate"], "expected_response": "We'd love to feature your success story! Our marketing team will reach out to discuss the case study process, including interviews and approval workflows. Thank you for offering!"},
        {"category": "other", "priority": 2, "escalation": False, "keywords": ["media", "journalist", "interview", "article"], "expected_response": "Thank you for your interest in covering our approach to customer support automation. I've forwarded your request to our PR team. They'll coordinate the interview and provide any information you need."},
        {"category": "other", "priority": 1, "escalation": False, "keywords": ["thank you", "appreciation", "excellent"], "expected_response": "Thank you so much for the kind words! I'll make sure Sarah knows about your positive feedback. We're thrilled we could help resolve your issue quickly!"},
        {"category": "other", "priority": 2, "escalation": False, "keywords": ["inquiry", "plans", "differences", "pricing"], "expected_response": "Great question! Premium includes advanced features, priority support, and higher usage limits. Enterprise adds team collaboration, custom integrations, and dedicated support. I can send you a detailed comparison sheet."},
    ]

    return emails, ground_truths


if __name__ == "__main__":
    emails, gts = get_email_dataset()
    print(f"Loaded {len(emails)} emails with ground truth labels")
    print(f"\nSample email:")
    print(f"  Subject: {emails[0]['subject']}")
    print(f"  Ground Truth: {gts[0]['category']}, Priority: {gts[0]['priority']}")
