export interface Email {
  id: string;
  emailId: string;
  subject: string;
  body: string;
  senderEmail: string;
  customerTier: 'free' | 'premium' | 'enterprise';
  receivedAt: string;
  source: 'real' | 'simulation';
  processed: boolean;
}

export interface AIDecision {
  id: string;
  emailId: string;
  category: 'billing' | 'technical' | 'account' | 'spam' | 'other';
  priority: number;
  sentiment: 'positive' | 'neutral' | 'negative';
  escalation: boolean;
  responseText: string;
  confidenceScore: number;
  processingTimeMs: number;
  agentType: 'ai' | 'baseline';
  createdAt: string;
}

export interface GroundTruth {
  id: string;
  emailId: string;
  category: string;
  priority: number;
  expectedResponse: string;
  escalation: boolean;
}

export interface PerformanceMetrics {
  id: string;
  emailId: string;
  taskLevel: 'easy' | 'medium' | 'hard';
  rewardScore: number;
  categoryCorrect: boolean;
  priorityError: number;
  responseSimilarity: number;
  escalationCorrect: boolean;
  slaPenalty: number;
  agentType: 'ai' | 'baseline';
}
