import { Email } from '../types';
import { AIAgent } from './aiAgent';
import { BaselineAgent } from './baselineAgent';

const aiAgent = new AIAgent();
const baselineAgent = new BaselineAgent();

export interface ProcessedEmail {
  category: string;
  priority: number;
  sentiment: string;
  escalation: boolean;
  response: string;
  confidence: number;
}

export async function processEmail(
  email: Email,
  agentType: 'ai' | 'baseline'
): Promise<ProcessedEmail> {
  await new Promise(resolve => setTimeout(resolve, 500));

  const emailData = {
    subject: email.subject,
    body: email.body,
    customer_tier: email.customerTier
  };

  if (agentType === 'ai') {
    return aiAgent.processEmail(emailData);
  } else {
    return baselineAgent.processEmail(emailData);
  }
}
