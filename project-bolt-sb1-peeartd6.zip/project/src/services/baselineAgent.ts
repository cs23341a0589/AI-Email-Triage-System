interface EmailData {
  subject: string;
  body: string;
  customer_tier: string;
}

interface ProcessedEmail {
  category: string;
  priority: number;
  sentiment: string;
  escalation: boolean;
  response: string;
  confidence: number;
}

export class BaselineAgent {
  private categoryKeywords: Record<string, string[]>;
  private responseTemplates: Record<string, string>;

  constructor() {
    this.categoryKeywords = {
      billing: ['charge', 'billing', 'invoice', 'payment', 'refund', 'credit', 'subscription', 'price'],
      technical: ['error', 'bug', 'crash', 'broken', 'not working', 'api', 'slow', 'issue'],
      account: ['password', 'login', 'account', 'access', 'locked', 'reset', '2fa'],
      spam: ['won', 'winner', 'prize', 'million', 'click here', 'guarantee', 'free money']
    };

    this.responseTemplates = {
      billing: "Dear valued customer,\n\nThank you for contacting us regarding your billing inquiry. We understand billing questions can be concerning, and we're here to help.\n\nOur billing team will review your account and respond within 24 hours with a detailed explanation. If you need immediate assistance, please don't hesitate to call our support line.\n\nBest regards,\nCustomer Support Team",
      technical: "Hello,\n\nThank you for reporting this technical issue. We take all technical problems seriously and will investigate this immediately.\n\nOur engineering team has been notified and will work to resolve this as quickly as possible. We'll keep you updated on the progress.\n\nExpected resolution time: 48 hours\n\nTechnical Support Team",
      account: "Dear customer,\n\nThank you for contacting us about your account. We're here to assist you with any account-related questions or changes.\n\nFor security purposes, we may need to verify your identity before making any account modifications. Our team will reach out to you shortly with next steps.\n\nBest regards,\nAccount Services Team",
      spam: "This email has been identified as potential spam and has been filtered accordingly.",
      other: "Dear customer,\n\nThank you for reaching out to us. We've received your message and will respond within 24-48 hours.\n\nIf your matter is urgent, please contact our priority support line.\n\nBest regards,\nCustomer Support Team"
    };
  }

  processEmail(email: EmailData): ProcessedEmail {
    const text = `${email.subject} ${email.body}`.toLowerCase();

    const category = this.classifyCategory(text);
    const priority = this.assignPriority(text, email.customer_tier, category);
    const sentiment = this.detectSentiment(text);
    const escalation = this.shouldEscalate(priority);
    const response = this.responseTemplates[category];

    return {
      category,
      priority,
      sentiment,
      escalation,
      response,
      confidence: 0.5
    };
  }

  private classifyCategory(text: string): string {
    const categoryScores: Record<string, number> = {};

    for (const [category, keywords] of Object.entries(this.categoryKeywords)) {
      categoryScores[category] = 0;
      for (const keyword of keywords) {
        if (text.includes(keyword)) {
          categoryScores[category]++;
        }
      }
    }

    if (categoryScores.spam >= 2) return 'spam';

    const maxScore = Math.max(...Object.values(categoryScores));
    if (maxScore === 0) return 'other';

    for (const [category, score] of Object.entries(categoryScores)) {
      if (score === maxScore && category !== 'spam') {
        return category;
      }
    }

    return 'other';
  }

  private assignPriority(text: string, customerTier: string, category: string): number {
    if (category === 'spam') return 1;

    let priority = 3;

    if (text.includes('urgent') || text.includes('immediately') || text.includes('critical')) {
      priority = 4;
    }

    if (customerTier === 'enterprise') {
      priority = Math.min(5, priority + 1);
    } else if (customerTier === 'free') {
      priority = Math.max(1, priority - 1);
    }

    return priority;
  }

  private detectSentiment(text: string): string {
    const negativeWords = ['angry', 'frustrated', 'terrible', 'horrible', 'unacceptable', 'worst'];
    const positiveWords = ['thank', 'appreciate', 'great', 'excellent', 'good'];

    let negativeCount = 0;
    let positiveCount = 0;

    for (const word of negativeWords) {
      if (text.includes(word)) negativeCount++;
    }

    for (const word of positiveWords) {
      if (text.includes(word)) positiveCount++;
    }

    const exclamationCount = (text.match(/!/g) || []).length;
    if (exclamationCount >= 5) negativeCount++;

    if (negativeCount > positiveCount) return 'negative';
    if (positiveCount > negativeCount) return 'positive';
    return 'neutral';
  }

  private shouldEscalate(priority: number): boolean {
    return priority >= 5;
  }
}
