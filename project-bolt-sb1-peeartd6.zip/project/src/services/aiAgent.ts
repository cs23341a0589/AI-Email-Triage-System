interface EmailData {
  subject: string;
  body: string;
  customer_tier: string;
}

interface ProcessedEmail {
  category: string;
  priority: number;
  sentiment: string;
  escalation: boolean;
  response: string;
  confidence: number;
}

export class AIAgent {
  private categoryPatterns: Record<string, RegExp[]>;
  private urgencyKeywords: string[];
  private positiveWords: Set<string>;
  private negativeWords: Set<string>;

  constructor() {
    this.categoryPatterns = {
      billing: [
        /\b(charge[ds]?|billing|invoice|payment|refund|credit card|subscription|price|cost)\b/i,
        /\b(double charge|overcharge|cancel.*account)\b/i,
        /\b(receipt|transaction|fee)\b/i
      ],
      technical: [
        /\b(error|bug|crash|broken|not working|fail|issue|problem)\b/i,
        /\b(api|integration|sync|upload|download|load)\b/i,
        /\b(slow|performance|timeout|connection)\b/i
      ],
      account: [
        /\b(password|login|access|account|username|2fa|two.?factor)\b/i,
        /\b(locked|suspended|reset|verify|delete.*account)\b/i,
        /\b(ownership|transfer|email.*change)\b/i
      ],
      spam: [
        /\b(won|winner|claim.*prize|million|lottery|click here|act fast)\b/i,
        /\b(congratulations|selected|lucky|free money|guarantee)\b/i,
        /\b(urgent.*suspend|verify.*credit)\b/i
      ]
    };

    this.urgencyKeywords = [
      'urgent', 'immediately', 'asap', 'critical', 'emergency', 'now',
      'production', 'blocking', 'data loss', 'down', 'outage'
    ];

    this.positiveWords = new Set([
      'thank', 'thanks', 'appreciate', 'excellent', 'great', 'good',
      'happy', 'satisfied', 'love', 'perfect', 'wonderful'
    ]);

    this.negativeWords = new Set([
      'angry', 'frustrated', 'terrible', 'horrible', 'awful', 'bad',
      'worst', 'unacceptable', 'disappointed', 'disgrace', 'furious',
      'pathetic', 'useless', 'broken', 'hate', 'ridiculous'
    ]);
  }

  processEmail(email: EmailData): ProcessedEmail {
    const fullText = `${email.subject} ${email.body}`.toLowerCase();

    const category = this.classifyCategory(fullText);
    const sentiment = this.analyzeSentiment(fullText);
    const basePriority = this.calculateBasePriority(fullText, category);
    const finalPriority = this.adjustPriority(basePriority, email.customer_tier, sentiment, fullText);
    const escalation = this.shouldEscalate(finalPriority, email.customer_tier, sentiment, category);
    const response = this.generateResponse(category, sentiment, email.customer_tier, escalation, email.subject, email.body);
    const confidence = this.calculateConfidence(category, fullText);

    return {
      category,
      priority: finalPriority,
      sentiment,
      escalation,
      response,
      confidence
    };
  }

  private classifyCategory(text: string): string {
    const scores: Record<string, number> = {};

    for (const [category, patterns] of Object.entries(this.categoryPatterns)) {
      scores[category] = 0;
      for (const pattern of patterns) {
        if (pattern.test(text)) {
          scores[category]++;
        }
      }
    }

    if (scores.spam >= 2) return 'spam';

    const maxScore = Math.max(...Object.values(scores));
    if (maxScore === 0) return 'other';

    for (const [category, score] of Object.entries(scores)) {
      if (score === maxScore && category !== 'spam') {
        return category;
      }
    }

    return 'other';
  }

  private analyzeSentiment(text: string): string {
    let positiveScore = 0;
    let negativeScore = 0;

    const words = text.split(/\s+/);
    for (const word of words) {
      if (this.positiveWords.has(word)) positiveScore++;
      if (this.negativeWords.has(word)) negativeScore++;
    }

    const capsRatio = text.split('').filter(c => c === c.toUpperCase() && c !== c.toLowerCase()).length / Math.max(text.length, 1);
    const exclamationCount = (text.match(/!/g) || []).length;

    if (capsRatio > 0.3 || exclamationCount >= 5) {
      negativeScore += 2;
    }

    if (negativeScore >= positiveScore + 2) return 'negative';
    if (positiveScore > negativeScore) return 'positive';
    return 'neutral';
  }

  private calculateBasePriority(text: string, category: string): number {
    const urgencyCount = this.urgencyKeywords.filter(kw => text.includes(kw)).length;

    if (category === 'spam') return 1;

    if (urgencyCount >= 3) return 5;
    if (urgencyCount >= 2) return 4;
    if (urgencyCount >= 1) return 3;

    if (category === 'technical') {
      if (/production|critical|data loss|down/.test(text)) return 5;
      if (/error|crash|broken/.test(text)) return 3;
      return 2;
    }

    if (category === 'billing') {
      if (/double charge|unauthorized|fraud/.test(text)) return 5;
      if (/refund|cancel/.test(text)) return 3;
      return 2;
    }

    if (category === 'account') {
      if (/locked|compromised|suspicious/.test(text)) return 4;
      return 3;
    }

    return 2;
  }

  private adjustPriority(basePriority: number, customerTier: string, sentiment: string, text: string): number {
    let priority = basePriority;

    if (customerTier === 'enterprise') priority = Math.min(5, priority + 1);
    else if (customerTier === 'free') priority = Math.max(1, priority - 1);

    if (sentiment === 'negative') priority = Math.min(5, priority + 1);

    const exclamationCount = (text.match(/!/g) || []).length;
    if (exclamationCount >= 5) priority = Math.min(5, priority + 1);

    return Math.max(1, Math.min(5, priority));
  }

  private shouldEscalate(priority: number, customerTier: string, sentiment: string, category: string): boolean {
    if (category === 'spam') return false;
    if (priority >= 5) return true;
    if (customerTier === 'enterprise' && priority >= 4) return true;
    if (sentiment === 'negative' && priority >= 4) return true;
    return false;
  }

  private generateResponse(category: string, sentiment: string, customerTier: string, escalation: boolean, subject: string, body: string): string {
    if (category === 'spam') {
      return 'This email has been automatically filtered as spam.';
    }

    const greeting = customerTier === 'enterprise' ? 'Dear valued enterprise customer,' : customerTier === 'premium' ? 'Hello,' : 'Hi there,';

    let acknowledgment = '';
    if (sentiment === 'negative') {
      const ackMap: Record<string, string> = {
        billing: "We sincerely apologize for any billing concerns. Your trust is important to us.",
        technical: "We understand how frustrating technical issues can be, and we're here to help.",
        account: "We take account security and access very seriously.",
        other: "We apologize for any inconvenience you've experienced."
      };
      acknowledgment = ackMap[category] || "We apologize for any inconvenience.";
    } else {
      const ackMap: Record<string, string> = {
        billing: "Thank you for contacting us regarding your billing inquiry.",
        technical: "Thank you for reporting this technical issue.",
        account: "Thank you for reaching out about your account.",
        other: "Thank you for contacting us."
      };
      acknowledgment = ackMap[category] || "Thank you for your message.";
    }

    let action = '';
    if (escalation) {
      action = "This matter has been escalated to our specialized team for immediate attention. A senior representative will contact you within 1 hour to resolve this issue.";
    } else {
      const text = (subject + ' ' + body).toLowerCase();
      if (category === 'billing') {
        if (text.includes('refund')) action = "I've initiated a refund request for review. Our billing team will process this within 5-7 business days.";
        else if (text.includes('charge')) action = "Our billing team will investigate this charge and contact you within 24 hours with a resolution.";
        else action = "Our billing specialists will review your inquiry and respond with detailed information shortly.";
      } else if (category === 'technical') {
        if (text.includes('crash') || text.includes('error')) action = "Our engineering team has been notified and is investigating this issue. We'll provide an update within 24-48 hours.";
        else if (text.includes('api')) action = "Our technical team will review your API integration and provide guidance on resolving the authentication issue.";
        else action = "We're looking into this technical issue and will work to resolve it as quickly as possible.";
      } else if (category === 'account') {
        if (text.includes('password') || text.includes('reset')) action = "I can help you reset your password. I'll send a password reset link to your registered email address.";
        else if (text.includes('locked')) action = "I've unlocked your account. Please try logging in again with your credentials.";
        else action = "Our account services team will assist you with this request. You can expect a response within 24 hours.";
      } else {
        action = "We've received your message and will respond within 24-48 hours. If this is urgent, please contact our priority support line.";
      }
    }

    const closing = escalation ? "We appreciate your patience as we prioritize your case.\n\nBest regards,\nPriority Support Team" : "Best regards,\nCustomer Support Team";

    return `${greeting}\n\n${acknowledgment}\n\n${action}\n\n${closing}`;
  }

  private calculateConfidence(category: string, text: string): number {
    if (category === 'spam') {
      const patternCount = this.categoryPatterns.spam.filter(p => p.test(text)).length;
      return Math.min(1.0, patternCount / 3);
    }

    const patterns = this.categoryPatterns[category] || [];
    const patternCount = patterns.filter(p => p.test(text)).length;
    return Math.min(1.0, patternCount / 2);
  }
}
