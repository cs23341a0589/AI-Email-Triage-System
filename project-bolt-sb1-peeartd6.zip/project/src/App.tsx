import Dashboard from './components/Dashboard';
import { EmailProvider } from './context/EmailContext';

function App() {
  return (
    <EmailProvider>
      <Dashboard />
    </EmailProvider>
  );
}

export default App;
