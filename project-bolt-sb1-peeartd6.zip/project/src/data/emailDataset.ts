import { Email } from '../types';

export const emailDataset: Email[] = [
  {
    id: 'e001',
    emailId: 'e001',
    subject: 'Urgent: Double charged on my credit card!',
    body: "I just noticed I was charged TWICE for my subscription this month. This is unacceptable! I need this fixed immediately or I'm canceling my account. My card ending in 4532 shows two charges of $49.99 each. Please refund one immediately.",
    senderEmail: 'customer1@example.com',
    customerTier: 'premium',
    receivedAt: new Date().toISOString(),
    source: 'simulation',
    processed: false
  },
  {
    id: 'e002',
    emailId: 'e002',
    subject: 'Question about invoice #12847',
    body: "Hello, I received invoice #12847 but I don't understand what the 'platform fee' charge is for. Could you please explain this? Also, is there a way to get an itemized breakdown? Thanks!",
    senderEmail: 'enterprise@company.com',
    customerTier: 'enterprise',
    receivedAt: new Date().toISOString(),
    source: 'simulation',
    processed: false
  },
  {
    id: 'e003',
    emailId: 'e003',
    subject: 'Payment failed - need help',
    body: "Hi, my payment keeps failing when I try to upgrade to premium. I've tried three different cards and none work. The error message says 'Payment processing error'. Can you help?",
    senderEmail: 'user@email.com',
    customerTier: 'free',
    receivedAt: new Date().toISOString(),
    source: 'simulation',
    processed: false
  },
  {
    id: 'e011',
    emailId: 'e011',
    subject: 'App crashes on startup',
    body: "The mobile app crashes immediately after I open it. I've tried uninstalling and reinstalling but the problem persists. I'm using iPhone 14 Pro with iOS 17.2. Please help!",
    senderEmail: 'mobile@user.com',
    customerTier: 'premium',
    receivedAt: new Date().toISOString(),
    source: 'simulation',
    processed: false
  },
  {
    id: 'e012',
    emailId: 'e012',
    subject: 'API integration not working',
    body: "We're trying to integrate your API but keep getting 401 errors. We've double-checked our API keys and they appear correct. Documentation says to use Bearer token but that's not working. Need urgent help as this is blocking our production deployment.",
    senderEmail: 'devteam@startup.io',
    customerTier: 'enterprise',
    receivedAt: new Date().toISOString(),
    source: 'simulation',
    processed: false
  },
  {
    id: 'e016',
    emailId: 'e016',
    subject: 'CRITICAL: Data loss after update',
    body: "After the update this morning, ALL of our project data is GONE! This is a critical issue affecting our entire team of 50 people. We need this restored immediately or we're facing serious business consequences!",
    senderEmail: 'cto@bigcorp.com',
    customerTier: 'enterprise',
    receivedAt: new Date().toISOString(),
    source: 'simulation',
    processed: false
  },
  {
    id: 'e026',
    emailId: 'e026',
    subject: "Can't log in - forgot password",
    body: "I forgot my password and the reset link doesn't seem to be working. I click 'Reset Password' but never receive an email. Can you help me regain access to my account?",
    senderEmail: 'forgetful@user.com',
    customerTier: 'free',
    receivedAt: new Date().toISOString(),
    source: 'simulation',
    processed: false
  },
  {
    id: 'e032',
    emailId: 'e032',
    subject: 'Suspicious activity on account',
    body: "I just received a notification about activity from an IP address I don't recognize in Russia. I haven't traveled there. Has my account been compromised?",
    senderEmail: 'security@minded.com',
    customerTier: 'enterprise',
    receivedAt: new Date().toISOString(),
    source: 'simulation',
    processed: false
  },
  {
    id: 'e036',
    emailId: 'e036',
    subject: '🎉 You\'ve won $1,000,000! Claim now!',
    body: 'Congratulations!!! You have been selected as our lucky winner! Click here to claim your prize of ONE MILLION DOLLARS. Act fast, this offer expires in 24 hours! Click now: http://suspicious-link.com',
    senderEmail: 'scammer@spam.com',
    customerTier: 'free',
    receivedAt: new Date().toISOString(),
    source: 'simulation',
    processed: false
  },
  {
    id: 'e042',
    emailId: 'e042',
    subject: 'Product feedback',
    body: "I've been using your product for 6 months and overall it's great! Just wanted to share some feedback on features that could be improved. The reporting module could use more customization options.",
    senderEmail: 'happy@customer.com',
    customerTier: 'premium',
    receivedAt: new Date().toISOString(),
    source: 'simulation',
    processed: false
  },
  {
    id: 'e049',
    emailId: 'e049',
    subject: 'Thank you!',
    body: "Just wanted to send a quick thank you to your support team. Sarah helped me resolve my issue in under 5 minutes. Excellent customer service!",
    senderEmail: 'grateful@user.com',
    customerTier: 'premium',
    receivedAt: new Date().toISOString(),
    source: 'simulation',
    processed: false
  },
  {
    id: 'e013',
    emailId: 'e013',
    subject: 'Data export feature broken',
    body: "When I try to export my data to CSV, I get an error message 'Export failed'. This has been happening for the past 3 days. I need this data for my quarterly report. Please fix ASAP.",
    senderEmail: 'analyst@company.com',
    customerTier: 'premium',
    receivedAt: new Date().toISOString(),
    source: 'simulation',
    processed: false
  },
  {
    id: 'e006',
    emailId: 'e006',
    subject: 'CHARGED AFTER CANCELLATION!!!',
    body: "I CANCELLED my subscription THREE WEEKS AGO and you STILL charged me today! This is THEFT! I want my money back NOW and I'm reporting this to my credit card company. This is completely unacceptable!",
    senderEmail: 'angry@customer.com',
    customerTier: 'free',
    receivedAt: new Date().toISOString(),
    source: 'simulation',
    processed: false
  },
  {
    id: 'e027',
    emailId: 'e027',
    subject: 'Account locked after failed login attempts',
    body: "My account has been locked due to failed login attempts. I was trying different passwords but now I'm completely locked out. Please unlock my account - this is urgent!",
    senderEmail: 'locked@out.com',
    customerTier: 'premium',
    receivedAt: new Date().toISOString(),
    source: 'simulation',
    processed: false
  },
  {
    id: 'e044',
    emailId: 'e044',
    subject: 'Training materials request',
    body: "We're onboarding 20 new employees next month. Do you have any training materials or videos we can use to get them up to speed quickly?",
    senderEmail: 'hr@company.com',
    customerTier: 'enterprise',
    receivedAt: new Date().toISOString(),
    source: 'simulation',
    processed: false
  },
  {
    id: 'e018',
    emailId: 'e018',
    subject: 'Webhook not triggering',
    body: "Our webhook endpoint hasn't received any events for the past 2 hours. We've checked our server logs and our endpoint is working fine. Is there an issue on your side?",
    senderEmail: 'webhook@dev.com',
    customerTier: 'enterprise',
    receivedAt: new Date().toISOString(),
    source: 'simulation',
    processed: false
  },
  {
    id: 'e050',
    emailId: 'e050',
    subject: 'General inquiry',
    body: "Hi, I'm considering your product for my small business. Can you tell me more about the differences between the premium and enterprise plans?",
    senderEmail: 'prospect@business.com',
    customerTier: 'free',
    receivedAt: new Date().toISOString(),
    source: 'simulation',
    processed: false
  },
  {
    id: 'e024',
    emailId: 'e024',
    subject: 'Security concern - SSL certificate',
    body: "My browser is showing a security warning about your SSL certificate. It says the certificate is invalid. This is concerning for our enterprise security policies.",
    senderEmail: 'security@enterprise.com',
    customerTier: 'enterprise',
    receivedAt: new Date().toISOString(),
    source: 'simulation',
    processed: false
  },
  {
    id: 'e004',
    emailId: 'e004',
    subject: 'Refund request',
    body: "I'd like to request a refund for the annual plan I purchased yesterday. I realized the features don't match what I need for my business. Order number: ORD-9482.",
    senderEmail: 'refund@request.com',
    customerTier: 'premium',
    receivedAt: new Date().toISOString(),
    source: 'simulation',
    processed: false
  },
  {
    id: 'e015',
    emailId: 'e015',
    subject: 'Feature request - dark mode',
    body: "Would love to see a dark mode option added to the app. Many of us work late hours and the bright interface is hard on the eyes. Thanks for considering!",
    senderEmail: 'nightowl@user.com',
    customerTier: 'free',
    receivedAt: new Date().toISOString(),
    source: 'simulation',
    processed: false
  }
];
