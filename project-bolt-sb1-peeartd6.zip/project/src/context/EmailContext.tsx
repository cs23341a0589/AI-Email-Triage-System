import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { Email, AIDecision, PerformanceMetrics } from '../types';
import { emailDataset } from '../data/emailDataset';
import { processEmail } from '../services/aiService';

interface EmailContextType {
  emails: Email[];
  decisions: Map<string, AIDecision>;
  metrics: PerformanceMetrics[];
  processEmailWithAI: (email: Email, agentType: 'ai' | 'baseline') => Promise<void>;
  selectedEmail: Email | null;
  setSelectedEmail: (email: Email | null) => void;
  loading: boolean;
}

const EmailContext = createContext<EmailContextType | undefined>(undefined);

export const EmailProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [emails, setEmails] = useState<Email[]>([]);
  const [decisions, setDecisions] = useState<Map<string, AIDecision>>(new Map());
  const [metrics, setMetrics] = useState<PerformanceMetrics[]>([]);
  const [selectedEmail, setSelectedEmail] = useState<Email | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    loadEmails();
  }, []);

  const loadEmails = () => {
    const loadedEmails = emailDataset.slice(0, 20);
    setEmails(loadedEmails);
    if (loadedEmails.length > 0 && !selectedEmail) {
      setSelectedEmail(loadedEmails[0]);
    }
  };

  const processEmailWithAI = async (email: Email, agentType: 'ai' | 'baseline') => {
    setLoading(true);
    try {
      const startTime = Date.now();
      const decision = await processEmail(email, agentType);
      const processingTime = Date.now() - startTime;

      const aiDecision: AIDecision = {
        id: `decision-${email.id}`,
        emailId: email.id,
        category: decision.category as 'billing' | 'technical' | 'account' | 'spam' | 'other',
        priority: decision.priority,
        sentiment: decision.sentiment as 'positive' | 'neutral' | 'negative',
        escalation: decision.escalation,
        responseText: decision.response,
        confidenceScore: decision.confidence,
        processingTimeMs: processingTime,
        agentType: agentType,
        createdAt: new Date().toISOString()
      };

      setDecisions(prev => new Map(prev).set(email.id, aiDecision));

      setEmails(prev =>
        prev.map(e => (e.id === email.id ? { ...e, processed: true } : e))
      );
    } catch (error) {
      console.error('Error processing email:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <EmailContext.Provider
      value={{
        emails,
        decisions,
        metrics,
        processEmailWithAI,
        selectedEmail,
        setSelectedEmail,
        loading
      }}
    >
      {children}
    </EmailContext.Provider>
  );
};

export const useEmail = () => {
  const context = useContext(EmailContext);
  if (context === undefined) {
    throw new Error('useEmail must be used within an EmailProvider');
  }
  return context;
};
