import { useEmail } from '../context/EmailContext';
import { Mail, User, Clock, Tag } from 'lucide-react';

export default function EmailDetail() {
  const { selectedEmail } = useEmail();

  if (!selectedEmail) {
    return (
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-12 text-center">
        <Mail className="w-12 h-12 text-slate-300 mx-auto mb-4" />
        <p className="text-slate-600">Select an email to view details</p>
      </div>
    );
  }

  const getCustomerTierColor = (tier: string) => {
    switch (tier) {
      case 'enterprise':
        return 'bg-purple-100 text-purple-700 border-purple-200';
      case 'premium':
        return 'bg-blue-100 text-blue-700 border-blue-200';
      default:
        return 'bg-slate-100 text-slate-700 border-slate-200';
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-slate-200">
      <div className="px-6 py-4 border-b border-slate-200 bg-slate-50">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-semibold text-slate-900">Email Details</h2>
          <span className={`text-xs px-3 py-1 rounded-full border font-medium ${getCustomerTierColor(selectedEmail.customerTier)}`}>
            {selectedEmail.customerTier}
          </span>
        </div>
      </div>

      <div className="p-6">
        <div className="space-y-4">
          <div>
            <div className="flex items-center space-x-2 text-sm text-slate-600 mb-2">
              <User className="w-4 h-4" />
              <span className="font-medium">From:</span>
              <span>{selectedEmail.senderEmail}</span>
            </div>
            <div className="flex items-center space-x-2 text-sm text-slate-600 mb-2">
              <Clock className="w-4 h-4" />
              <span className="font-medium">Received:</span>
              <span>{new Date(selectedEmail.receivedAt).toLocaleString()}</span>
            </div>
            <div className="flex items-center space-x-2 text-sm text-slate-600">
              <Tag className="w-4 h-4" />
              <span className="font-medium">ID:</span>
              <span className="font-mono text-xs">{selectedEmail.emailId}</span>
            </div>
          </div>

          <div className="border-t border-slate-200 pt-4">
            <h3 className="text-lg font-semibold text-slate-900 mb-3">
              {selectedEmail.subject}
            </h3>
            <div className="prose prose-sm max-w-none">
              <p className="text-slate-700 whitespace-pre-wrap leading-relaxed">
                {selectedEmail.body}
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
