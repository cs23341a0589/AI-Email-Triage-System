import { useEmail } from '../context/EmailContext';
import { BarChart3, TrendingUp, AlertTriangle, Clock, Target } from 'lucide-react';

export default function StatsPanel() {
  const { emails, decisions } = useEmail();

  const decisionList = Array.from(decisions.values());

  const categoryCount = decisionList.reduce((acc, decision) => {
    acc[decision.category] = (acc[decision.category] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  const avgPriority = decisionList.length > 0
    ? (decisionList.reduce((sum, d) => sum + d.priority, 0) / decisionList.length).toFixed(1)
    : '0';

  const escalationCount = decisionList.filter(d => d.escalation).length;
  const escalationRate = decisionList.length > 0
    ? ((escalationCount / decisionList.length) * 100).toFixed(0)
    : '0';

  const sentimentCount = decisionList.reduce((acc, decision) => {
    acc[decision.sentiment] = (acc[decision.sentiment] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  const avgProcessingTime = decisionList.length > 0
    ? Math.round(decisionList.reduce((sum, d) => sum + d.processingTimeMs, 0) / decisionList.length)
    : 0;

  const tierCount = emails.reduce((acc, email) => {
    acc[email.customerTier] = (acc[email.customerTier] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-4 gap-4">
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium text-slate-600">Processed</span>
            <BarChart3 className="w-4 h-4 text-blue-600" />
          </div>
          <div className="text-3xl font-bold text-slate-900">{decisionList.length}</div>
          <div className="text-xs text-slate-600 mt-1">of {emails.length} total</div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium text-slate-600">Avg Priority</span>
            <TrendingUp className="w-4 h-4 text-orange-600" />
          </div>
          <div className="text-3xl font-bold text-slate-900">{avgPriority}</div>
          <div className="text-xs text-slate-600 mt-1">out of 5</div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium text-slate-600">Escalation Rate</span>
            <AlertTriangle className="w-4 h-4 text-red-600" />
          </div>
          <div className="text-3xl font-bold text-slate-900">{escalationRate}%</div>
          <div className="text-xs text-slate-600 mt-1">{escalationCount} escalated</div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium text-slate-600">Avg Time</span>
            <Clock className="w-4 h-4 text-green-600" />
          </div>
          <div className="text-3xl font-bold text-slate-900">{avgProcessingTime}</div>
          <div className="text-xs text-slate-600 mt-1">milliseconds</div>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-6">
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
          <h3 className="text-lg font-semibold text-slate-900 mb-4 flex items-center space-x-2">
            <Target className="w-5 h-5 text-blue-600" />
            <span>Category Distribution</span>
          </h3>
          <div className="space-y-3">
            {Object.entries(categoryCount).map(([category, count]) => {
              const percentage = ((count / decisionList.length) * 100).toFixed(0);
              return (
                <div key={category}>
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-sm font-medium text-slate-700 capitalize">{category}</span>
                    <span className="text-sm font-semibold text-slate-900">{count} ({percentage}%)</span>
                  </div>
                  <div className="w-full bg-slate-200 rounded-full h-2">
                    <div
                      className="bg-gradient-to-r from-blue-500 to-indigo-500 h-2 rounded-full transition-all"
                      style={{ width: `${percentage}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
          <h3 className="text-lg font-semibold text-slate-900 mb-4 flex items-center space-x-2">
            <Target className="w-5 h-5 text-blue-600" />
            <span>Sentiment Analysis</span>
          </h3>
          <div className="space-y-4">
            {Object.entries(sentimentCount).map(([sentiment, count]) => {
              const percentage = ((count / decisionList.length) * 100).toFixed(0);
              const emoji = sentiment === 'positive' ? '😊' : sentiment === 'negative' ? '😠' : '😐';
              const color = sentiment === 'positive' ? 'from-green-500 to-emerald-500' : sentiment === 'negative' ? 'from-red-500 to-rose-500' : 'from-slate-400 to-slate-500';
              return (
                <div key={sentiment}>
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-sm font-medium text-slate-700 capitalize flex items-center space-x-2">
                      <span className="text-xl">{emoji}</span>
                      <span>{sentiment}</span>
                    </span>
                    <span className="text-sm font-semibold text-slate-900">{count} ({percentage}%)</span>
                  </div>
                  <div className="w-full bg-slate-200 rounded-full h-2">
                    <div
                      className={`bg-gradient-to-r ${color} h-2 rounded-full transition-all`}
                      style={{ width: `${percentage}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
        <h3 className="text-lg font-semibold text-slate-900 mb-4">Customer Tier Distribution</h3>
        <div className="grid grid-cols-3 gap-4">
          {Object.entries(tierCount).map(([tier, count]) => {
            const percentage = ((count / emails.length) * 100).toFixed(0);
            const color = tier === 'enterprise' ? 'from-purple-500 to-indigo-500' : tier === 'premium' ? 'from-blue-500 to-cyan-500' : 'from-slate-400 to-slate-500';
            return (
              <div key={tier} className="text-center">
                <div className={`w-20 h-20 mx-auto mb-2 bg-gradient-to-br ${color} rounded-full flex items-center justify-center text-white text-2xl font-bold`}>
                  {count}
                </div>
                <div className="text-sm font-semibold text-slate-900 capitalize">{tier}</div>
                <div className="text-xs text-slate-600">{percentage}% of total</div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
