import { useEmail } from '../context/EmailContext';
import { CheckCircle2, Circle, AlertCircle } from 'lucide-react';

export default function EmailList() {
  const { emails, selectedEmail, setSelectedEmail, decisions } = useEmail();

  const getCustomerTierColor = (tier: string) => {
    switch (tier) {
      case 'enterprise':
        return 'bg-purple-100 text-purple-700 border-purple-200';
      case 'premium':
        return 'bg-blue-100 text-blue-700 border-blue-200';
      default:
        return 'bg-slate-100 text-slate-700 border-slate-200';
    }
  };

  const getPriorityColor = (priority: number) => {
    if (priority >= 5) return 'text-red-600';
    if (priority >= 4) return 'text-orange-600';
    if (priority >= 3) return 'text-yellow-600';
    return 'text-slate-600';
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
      <div className="px-4 py-3 border-b border-slate-200 bg-slate-50">
        <h2 className="text-sm font-semibold text-slate-900">Incoming Emails</h2>
        <p className="text-xs text-slate-600 mt-1">{emails.length} total emails</p>
      </div>

      <div className="divide-y divide-slate-100 max-h-[calc(100vh-300px)] overflow-y-auto">
        {emails.map(email => {
          const decision = decisions.get(email.id);
          const isSelected = selectedEmail?.id === email.id;

          return (
            <button
              key={email.id}
              onClick={() => setSelectedEmail(email)}
              className={`w-full text-left px-4 py-3 hover:bg-slate-50 transition-colors ${
                isSelected ? 'bg-blue-50 border-l-4 border-blue-500' : ''
              }`}
            >
              <div className="flex items-start justify-between mb-2">
                <div className="flex items-center space-x-2">
                  {email.processed ? (
                    <CheckCircle2 className="w-4 h-4 text-green-500 flex-shrink-0" />
                  ) : (
                    <Circle className="w-4 h-4 text-slate-400 flex-shrink-0" />
                  )}
                  <span className={`text-xs px-2 py-0.5 rounded-full border font-medium ${getCustomerTierColor(email.customerTier)}`}>
                    {email.customerTier}
                  </span>
                </div>
                {decision && decision.escalation && (
                  <AlertCircle className="w-4 h-4 text-red-500 flex-shrink-0" />
                )}
              </div>

              <h3 className="text-sm font-medium text-slate-900 mb-1 line-clamp-1">
                {email.subject}
              </h3>

              <p className="text-xs text-slate-600 line-clamp-2 mb-2">
                {email.body}
              </p>

              {decision && (
                <div className="flex items-center space-x-2 text-xs">
                  <span className="px-2 py-0.5 bg-slate-100 text-slate-700 rounded font-medium">
                    {decision.category}
                  </span>
                  <span className={`font-semibold ${getPriorityColor(decision.priority)}`}>
                    P{decision.priority}
                  </span>
                  <span className="text-slate-500">
                    {decision.sentiment}
                  </span>
                </div>
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
}
