import { useState } from 'react';
import { useEmail } from '../context/EmailContext';
import { Brain, Send, AlertTriangle, TrendingUp, Clock, Target, MessageSquare } from 'lucide-react';

export default function AIDecisionPanel() {
  const { selectedEmail, decisions, processEmailWithAI, loading } = useEmail();
  const [selectedAgent, setSelectedAgent] = useState<'ai' | 'baseline'>('ai');

  if (!selectedEmail) {
    return null;
  }

  const decision = decisions.get(selectedEmail.id);

  const handleProcess = async () => {
    if (!selectedEmail) return;
    await processEmailWithAI(selectedEmail, selectedAgent);
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'billing':
        return 'bg-green-100 text-green-700 border-green-200';
      case 'technical':
        return 'bg-red-100 text-red-700 border-red-200';
      case 'account':
        return 'bg-blue-100 text-blue-700 border-blue-200';
      case 'spam':
        return 'bg-slate-100 text-slate-700 border-slate-200';
      default:
        return 'bg-yellow-100 text-yellow-700 border-yellow-200';
    }
  };

  const getPriorityColor = (priority: number) => {
    if (priority >= 5) return 'bg-red-500';
    if (priority >= 4) return 'bg-orange-500';
    if (priority >= 3) return 'bg-yellow-500';
    if (priority >= 2) return 'bg-blue-500';
    return 'bg-slate-500';
  };

  const getSentimentEmoji = (sentiment: string) => {
    switch (sentiment) {
      case 'positive':
        return '😊';
      case 'negative':
        return '😠';
      default:
        return '😐';
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-slate-200">
      <div className="px-6 py-4 border-b border-slate-200 bg-slate-50">
        <h2 className="text-lg font-semibold text-slate-900 flex items-center space-x-2">
          <Brain className="w-5 h-5 text-blue-600" />
          <span>AI Decision Engine</span>
        </h2>
      </div>

      <div className="p-6">
        {!decision ? (
          <div className="space-y-4">
            <div className="text-center py-8">
              <Brain className="w-12 h-12 text-slate-300 mx-auto mb-4" />
              <p className="text-slate-600 mb-4">Process this email with AI to see intelligent decisions</p>

              <div className="flex justify-center space-x-2 mb-4">
                <button
                  onClick={() => setSelectedAgent('ai')}
                  className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                    selectedAgent === 'ai'
                      ? 'bg-blue-600 text-white'
                      : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                  }`}
                >
                  AI Agent
                </button>
                <button
                  onClick={() => setSelectedAgent('baseline')}
                  className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                    selectedAgent === 'baseline'
                      ? 'bg-blue-600 text-white'
                      : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                  }`}
                >
                  Baseline Agent
                </button>
              </div>

              <button
                onClick={handleProcess}
                disabled={loading}
                className="inline-flex items-center space-x-2 px-6 py-3 bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-lg font-medium hover:from-blue-700 hover:to-indigo-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <Brain className="w-4 h-4" />
                <span>{loading ? 'Processing...' : 'Process Email'}</span>
              </button>
            </div>
          </div>
        ) : (
          <div className="space-y-6">
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-slate-50 rounded-lg p-4 border border-slate-200">
                <div className="flex items-center space-x-2 mb-2">
                  <Target className="w-4 h-4 text-slate-600" />
                  <span className="text-xs font-medium text-slate-600">Category</span>
                </div>
                <span className={`inline-block px-3 py-1 rounded-lg border text-sm font-semibold ${getCategoryColor(decision.category)}`}>
                  {decision.category}
                </span>
              </div>

              <div className="bg-slate-50 rounded-lg p-4 border border-slate-200">
                <div className="flex items-center space-x-2 mb-2">
                  <TrendingUp className="w-4 h-4 text-slate-600" />
                  <span className="text-xs font-medium text-slate-600">Priority</span>
                </div>
                <div className="flex items-center space-x-2">
                  <div className="flex space-x-1">
                    {[1, 2, 3, 4, 5].map(level => (
                      <div
                        key={level}
                        className={`w-6 h-6 rounded ${
                          level <= decision.priority ? getPriorityColor(decision.priority) : 'bg-slate-200'
                        }`}
                      />
                    ))}
                  </div>
                  <span className="text-sm font-bold text-slate-900">{decision.priority}/5</span>
                </div>
              </div>

              <div className="bg-slate-50 rounded-lg p-4 border border-slate-200">
                <div className="flex items-center space-x-2 mb-2">
                  <MessageSquare className="w-4 h-4 text-slate-600" />
                  <span className="text-xs font-medium text-slate-600">Sentiment</span>
                </div>
                <div className="flex items-center space-x-2">
                  <span className="text-2xl">{getSentimentEmoji(decision.sentiment)}</span>
                  <span className="text-sm font-semibold text-slate-900 capitalize">{decision.sentiment}</span>
                </div>
              </div>

              <div className="bg-slate-50 rounded-lg p-4 border border-slate-200">
                <div className="flex items-center space-x-2 mb-2">
                  <AlertTriangle className="w-4 h-4 text-slate-600" />
                  <span className="text-xs font-medium text-slate-600">Escalation</span>
                </div>
                <span className={`inline-block px-3 py-1 rounded-lg text-sm font-semibold ${
                  decision.escalation
                    ? 'bg-red-100 text-red-700 border border-red-200'
                    : 'bg-green-100 text-green-700 border border-green-200'
                }`}>
                  {decision.escalation ? 'Yes - Escalate' : 'No Escalation'}
                </span>
              </div>
            </div>

            <div className="border-t border-slate-200 pt-6">
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-sm font-semibold text-slate-900 flex items-center space-x-2">
                  <MessageSquare className="w-4 h-4" />
                  <span>Generated Response</span>
                </h3>
                <div className="flex items-center space-x-4 text-xs text-slate-600">
                  <span className="flex items-center space-x-1">
                    <Clock className="w-3 h-3" />
                    <span>{decision.processingTimeMs}ms</span>
                  </span>
                  <span className="flex items-center space-x-1">
                    <TrendingUp className="w-3 h-3" />
                    <span>Confidence: {(decision.confidenceScore * 100).toFixed(0)}%</span>
                  </span>
                  <span className="px-2 py-0.5 bg-blue-100 text-blue-700 rounded font-medium">
                    {decision.agentType.toUpperCase()}
                  </span>
                </div>
              </div>

              <div className="bg-slate-50 rounded-lg p-4 border border-slate-200">
                <p className="text-sm text-slate-700 whitespace-pre-wrap leading-relaxed">
                  {decision.responseText}
                </p>
              </div>

              <button
                className="mt-4 w-full inline-flex items-center justify-center space-x-2 px-6 py-3 bg-gradient-to-r from-green-600 to-emerald-600 text-white rounded-lg font-medium hover:from-green-700 hover:to-emerald-700 transition-colors"
                onClick={() => {}}
              >
                <Send className="w-4 h-4" />
                <span>Send Reply</span>
              </button>
            </div>

            <button
              onClick={handleProcess}
              disabled={loading}
              className="w-full inline-flex items-center justify-center space-x-2 px-6 py-2 bg-slate-100 text-slate-700 rounded-lg font-medium hover:bg-slate-200 transition-colors disabled:opacity-50"
            >
              <Brain className="w-4 h-4" />
              <span>{loading ? 'Processing...' : 'Reprocess with ' + (selectedAgent === 'ai' ? 'Baseline' : 'AI')}</span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
