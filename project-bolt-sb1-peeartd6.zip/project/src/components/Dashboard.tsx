import { useState } from 'react';
import { useEmail } from '../context/EmailContext';
import EmailList from './EmailList';
import EmailDetail from './EmailDetail';
import AIDecisionPanel from './AIDecisionPanel';
import StatsPanel from './StatsPanel';
import { Mail, Brain, BarChart3 } from 'lucide-react';

export default function Dashboard() {
  const { emails } = useEmail();
  const [activeTab, setActiveTab] = useState<'emails' | 'stats'>('emails');

  const processedCount = emails.filter(e => e.processed).length;
  const totalCount = emails.length;

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      <header className="bg-white border-b border-slate-200 shadow-sm">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-lg flex items-center justify-center">
                <Brain className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-slate-900">AI Email Triage System</h1>
                <p className="text-sm text-slate-600">Intelligent Auto-Reply & OpenEnv Training</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <div className="bg-slate-100 rounded-lg px-4 py-2">
                <div className="text-xs text-slate-600 font-medium">Processed</div>
                <div className="text-lg font-bold text-slate-900">{processedCount}/{totalCount}</div>
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-6 py-6">
        <div className="flex space-x-2 mb-6">
          <button
            onClick={() => setActiveTab('emails')}
            className={`flex items-center space-x-2 px-4 py-2 rounded-lg font-medium transition-colors ${
              activeTab === 'emails'
                ? 'bg-white text-blue-600 shadow-sm'
                : 'text-slate-600 hover:bg-white hover:shadow-sm'
            }`}
          >
            <Mail className="w-4 h-4" />
            <span>Email Triage</span>
          </button>
          <button
            onClick={() => setActiveTab('stats')}
            className={`flex items-center space-x-2 px-4 py-2 rounded-lg font-medium transition-colors ${
              activeTab === 'stats'
                ? 'bg-white text-blue-600 shadow-sm'
                : 'text-slate-600 hover:bg-white hover:shadow-sm'
            }`}
          >
            <BarChart3 className="w-4 h-4" />
            <span>Analytics</span>
          </button>
        </div>

        {activeTab === 'emails' ? (
          <div className="grid grid-cols-12 gap-6">
            <div className="col-span-4">
              <EmailList />
            </div>
            <div className="col-span-8">
              <div className="space-y-6">
                <EmailDetail />
                <AIDecisionPanel />
              </div>
            </div>
          </div>
        ) : (
          <StatsPanel />
        )}
      </div>
    </div>
  );
}
