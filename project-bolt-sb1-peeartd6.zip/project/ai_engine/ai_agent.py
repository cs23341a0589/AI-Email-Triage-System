"""
AI Agent with Intelligent Decision Making
Not just text generation - includes logic, sentiment analysis, SLA tracking, and escalation rules
"""

import re
from typing import Dict, Any
from .sentiment_analyzer import SentimentAnalyzer


class AIAgent:
    """
    Intelligent AI Agent for Email Triage

    Features:
    - Category classification
    - Priority assignment based on multiple factors
    - Sentiment detection
    - Escalation logic (customer tier + priority + sentiment)
    - Response generation with context awareness
    - SLA-based scoring
    """

    def __init__(self, model_name: str = "gpt-4"):
        """Initialize AI agent"""
        self.model_name = model_name
        self.sentiment_analyzer = SentimentAnalyzer()

        self.category_patterns = {
            'billing': [
                r'\b(charge[ds]?|billing|invoice|payment|refund|credit card|subscription|price|cost)\b',
                r'\b(double charge|overcharge|cancel.*account)\b',
                r'\b(receipt|transaction|fee)\b'
            ],
            'technical': [
                r'\b(error|bug|crash|broken|not working|fail|issue|problem)\b',
                r'\b(api|integration|sync|upload|download|load)\b',
                r'\b(slow|performance|timeout|connection)\b'
            ],
            'account': [
                r'\b(password|login|access|account|username|2fa|two.?factor)\b',
                r'\b(locked|suspended|reset|verify|delete.*account)\b',
                r'\b(ownership|transfer|email.*change)\b'
            ],
            'spam': [
                r'\b(won|winner|claim.*prize|million|lottery|click here|act fast)\b',
                r'\b(congratulations|selected|lucky|free money|guarantee)\b',
                r'\b(urgent.*suspend|verify.*credit)\b',
                r'http://[a-z\-]+\.(com|net|org)/[a-z]+\.exe'
            ]
        }

        self.urgency_keywords = [
            'urgent', 'immediately', 'asap', 'critical', 'emergency', 'now',
            'production', 'blocking', 'data loss', 'down', 'outage'
        ]

    def process_email(self, email: Dict[str, Any]) -> Dict[str, Any]:
        """
        Process email with intelligent decision making

        Args:
            email: Email dictionary with subject, body, customer_tier

        Returns:
            Decision dictionary with category, priority, sentiment, escalation, response
        """
        subject = email.get('subject', '')
        body = email.get('body', '')
        customer_tier = email.get('customer_tier', 'free')

        full_text = f"{subject} {body}".lower()

        category = self._classify_category(full_text)

        sentiment = self.sentiment_analyzer.analyze(full_text)

        base_priority = self._calculate_base_priority(full_text, category)

        final_priority = self._adjust_priority(
            base_priority,
            customer_tier,
            sentiment,
            full_text
        )

        escalation = self._should_escalate(
            final_priority,
            customer_tier,
            sentiment,
            category
        )

        response = self._generate_response(
            category,
            sentiment,
            customer_tier,
            escalation,
            subject,
            body
        )

        return {
            'category': category,
            'priority': final_priority,
            'sentiment': sentiment,
            'escalation': escalation,
            'response': response,
            'confidence': self._calculate_confidence(category, full_text)
        }

    def _classify_category(self, text: str) -> str:
        """
        Classify email category using pattern matching

        Args:
            text: Email text (subject + body)

        Returns:
            Category: billing, technical, account, spam, or other
        """
        scores = {category: 0 for category in self.category_patterns.keys()}

        for category, patterns in self.category_patterns.items():
            for pattern in patterns:
                if re.search(pattern, text, re.IGNORECASE):
                    scores[category] += 1

        if scores['spam'] >= 2:
            return 'spam'

        max_score = max(scores.values())
        if max_score == 0:
            return 'other'

        for category, score in scores.items():
            if score == max_score and category != 'spam':
                return category

        return 'other'

    def _calculate_base_priority(self, text: str, category: str) -> int:
        """
        Calculate base priority (1-5) based on content analysis

        Args:
            text: Email text
            category: Email category

        Returns:
            Priority level 1-5
        """
        urgency_count = sum(1 for keyword in self.urgency_keywords if keyword in text)

        if category == 'spam':
            return 1

        if urgency_count >= 3:
            return 5
        elif urgency_count >= 2:
            return 4
        elif urgency_count >= 1:
            return 3

        if category == 'technical':
            if any(word in text for word in ['production', 'critical', 'data loss', 'down']):
                return 5
            elif any(word in text for word in ['error', 'crash', 'broken']):
                return 3
            else:
                return 2

        elif category == 'billing':
            if any(word in text for word in ['double charge', 'unauthorized', 'fraud']):
                return 5
            elif any(word in text for word in ['refund', 'cancel']):
                return 3
            else:
                return 2

        elif category == 'account':
            if any(word in text for word in ['locked', 'compromised', 'suspicious']):
                return 4
            else:
                return 3

        return 2

    def _adjust_priority(self, base_priority: int, customer_tier: str,
                        sentiment: str, text: str) -> int:
        """
        Adjust priority based on customer tier and sentiment

        Args:
            base_priority: Initial priority
            customer_tier: free, premium, enterprise
            sentiment: positive, neutral, negative
            text: Email text

        Returns:
            Adjusted priority (1-5)
        """
        priority = base_priority

        if customer_tier == 'enterprise':
            priority = min(5, priority + 1)
        elif customer_tier == 'free':
            priority = max(1, priority - 1)

        if sentiment == 'negative':
            priority = min(5, priority + 1)

        exclamation_count = text.count('!')
        if exclamation_count >= 5:
            priority = min(5, priority + 1)

        caps_ratio = sum(1 for c in text if c.isupper()) / max(len(text), 1)
        if caps_ratio > 0.3:
            priority = min(5, priority + 1)

        return max(1, min(5, priority))

    def _should_escalate(self, priority: int, customer_tier: str,
                        sentiment: str, category: str) -> bool:
        """
        Determine if email should be escalated to human agent

        Escalation Rules:
        - Priority 5 (critical) → always escalate
        - Enterprise + Priority >= 4 → escalate
        - Negative sentiment + Priority >= 4 → escalate
        - Data loss / security issues → escalate
        - Spam → never escalate

        Args:
            priority: Priority level
            customer_tier: Customer tier
            sentiment: Sentiment analysis result
            category: Email category

        Returns:
            Boolean indicating escalation
        """
        if category == 'spam':
            return False

        if priority >= 5:
            return True

        if customer_tier == 'enterprise' and priority >= 4:
            return True

        if sentiment == 'negative' and priority >= 4:
            return True

        return False

    def _generate_response(self, category: str, sentiment: str,
                          customer_tier: str, escalation: bool,
                          subject: str, body: str) -> str:
        """
        Generate contextual response based on email analysis

        Args:
            category: Email category
            sentiment: Sentiment
            customer_tier: Customer tier
            escalation: Whether escalating
            subject: Email subject
            body: Email body

        Returns:
            Professional response text
        """
        if category == 'spam':
            return "This email has been automatically filtered as spam."

        greeting = self._get_greeting(customer_tier)
        acknowledgment = self._get_acknowledgment(category, sentiment)
        action = self._get_action(category, escalation, subject, body)
        closing = self._get_closing(escalation)

        response = f"{greeting}\n\n{acknowledgment}\n\n{action}\n\n{closing}"

        return response

    def _get_greeting(self, customer_tier: str) -> str:
        """Get appropriate greeting based on customer tier"""
        if customer_tier == 'enterprise':
            return "Dear valued enterprise customer,"
        elif customer_tier == 'premium':
            return "Hello,"
        else:
            return "Hi there,"

    def _get_acknowledgment(self, category: str, sentiment: str) -> str:
        """Get acknowledgment based on category and sentiment"""
        if sentiment == 'negative':
            ack_map = {
                'billing': "We sincerely apologize for any billing concerns. Your trust is important to us.",
                'technical': "We understand how frustrating technical issues can be, and we're here to help.",
                'account': "We take account security and access very seriously.",
                'other': "We apologize for any inconvenience you've experienced."
            }
        else:
            ack_map = {
                'billing': "Thank you for contacting us regarding your billing inquiry.",
                'technical': "Thank you for reporting this technical issue.",
                'account': "Thank you for reaching out about your account.",
                'other': "Thank you for contacting us."
            }

        return ack_map.get(category, "Thank you for your message.")

    def _get_action(self, category: str, escalation: bool, subject: str, body: str) -> str:
        """Get action statement based on category and escalation"""
        text = (subject + ' ' + body).lower()

        if escalation:
            return ("This matter has been escalated to our specialized team for immediate attention. "
                   "A senior representative will contact you within 1 hour to resolve this issue.")

        if category == 'billing':
            if 'refund' in text:
                return "I've initiated a refund request for review. Our billing team will process this within 5-7 business days."
            elif 'charge' in text:
                return "Our billing team will investigate this charge and contact you within 24 hours with a resolution."
            else:
                return "Our billing specialists will review your inquiry and respond with detailed information shortly."

        elif category == 'technical':
            if 'crash' in text or 'error' in text:
                return "Our engineering team has been notified and is investigating this issue. We'll provide an update within 24-48 hours."
            elif 'api' in text:
                return "Our technical team will review your API integration and provide guidance on resolving the authentication issue."
            else:
                return "We're looking into this technical issue and will work to resolve it as quickly as possible."

        elif category == 'account':
            if 'password' in text or 'reset' in text:
                return "I can help you reset your password. I'll send a password reset link to your registered email address."
            elif 'locked' in text:
                return "I've unlocked your account. Please try logging in again with your credentials."
            else:
                return "Our account services team will assist you with this request. You can expect a response within 24 hours."

        else:
            return "We've received your message and will respond within 24-48 hours. If this is urgent, please contact our priority support line."

    def _get_closing(self, escalation: bool) -> str:
        """Get appropriate closing"""
        if escalation:
            return "We appreciate your patience as we prioritize your case.\n\nBest regards,\nPriority Support Team"
        else:
            return "Best regards,\nCustomer Support Team"

    def _calculate_confidence(self, category: str, text: str) -> float:
        """Calculate confidence score for the classification"""
        if category == 'spam':
            pattern_count = sum(
                1 for pattern in self.category_patterns['spam']
                if re.search(pattern, text, re.IGNORECASE)
            )
            return min(1.0, pattern_count / 3)

        pattern_count = sum(
            1 for pattern in self.category_patterns.get(category, [])
            if re.search(pattern, text, re.IGNORECASE)
        )

        return min(1.0, pattern_count / 2)


if __name__ == "__main__":
    agent = AIAgent()

    test_email = {
        'subject': 'URGENT: API integration broken in production!',
        'body': 'Our production API integration is completely broken. Getting 401 errors. This is blocking our entire business. Need immediate help!',
        'customer_tier': 'enterprise'
    }

    result = agent.process_email(test_email)
    print("AI Agent Test:")
    print(f"Category: {result['category']}")
    print(f"Priority: {result['priority']}")
    print(f"Sentiment: {result['sentiment']}")
    print(f"Escalation: {result['escalation']}")
    print(f"Confidence: {result['confidence']:.2f}")
    print(f"\nResponse:\n{result['response']}")
