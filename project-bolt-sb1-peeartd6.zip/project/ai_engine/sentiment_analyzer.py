"""
Sentiment Analyzer for Email Triage
Detects positive, neutral, and negative sentiment to inform priority and escalation
"""

import re
from typing import Dict


class SentimentAnalyzer:
    """
    Rule-based sentiment analyzer optimized for customer support emails
    """

    def __init__(self):
        """Initialize sentiment analyzer with lexicons"""

        self.positive_words = {
            'thank', 'thanks', 'appreciate', 'excellent', 'great', 'good',
            'happy', 'satisfied', 'love', 'perfect', 'wonderful', 'amazing',
            'pleased', 'helpful', 'resolved', 'awesome', 'fantastic'
        }

        self.negative_words = {
            'angry', 'frustrated', 'terrible', 'horrible', 'awful', 'bad',
            'worst', 'unacceptable', 'disappointed', 'disgrace', 'furious',
            'pathetic', 'useless', 'broken', 'hate', 'never', 'ridiculous',
            'incompetent', 'disgust', 'outrage', 'theft', 'scam', 'fraud'
        }

        self.negative_phrases = [
            r'not working',
            r'does not work',
            r'doesn\'t work',
            r'total disaster',
            r'complete failure',
            r'waste of (?:time|money)',
            r'going to cancel',
            r'want (?:refund|money back)',
            r'filing (?:complaint|report)',
            r'never (?:again|use)',
            r'reporting (?:to|you)',
        ]

        self.urgency_intensifiers = {
            'urgent', 'immediately', 'now', 'asap', 'emergency', 'critical'
        }

    def analyze(self, text: str) -> str:
        """
        Analyze sentiment of email text

        Args:
            text: Email text (subject + body)

        Returns:
            'positive', 'neutral', or 'negative'
        """
        text_lower = text.lower()

        positive_score = self._calculate_positive_score(text_lower)
        negative_score = self._calculate_negative_score(text_lower)

        caps_ratio = self._calculate_caps_ratio(text)
        exclamation_count = text.count('!')

        if caps_ratio > 0.3 or exclamation_count >= 5:
            negative_score += 2

        has_urgency = any(word in text_lower for word in self.urgency_intensifiers)
        if has_urgency:
            negative_score += 1

        if negative_score >= positive_score + 2:
            return 'negative'
        elif positive_score > negative_score:
            return 'positive'
        else:
            return 'neutral'

    def _calculate_positive_score(self, text: str) -> int:
        """Calculate positive sentiment score"""
        score = 0

        words = set(text.split())
        for word in self.positive_words:
            if word in words:
                score += 1

        return score

    def _calculate_negative_score(self, text: str) -> int:
        """Calculate negative sentiment score"""
        score = 0

        words = set(text.split())
        for word in self.negative_words:
            if word in words:
                score += 1

        for phrase in self.negative_phrases:
            if re.search(phrase, text):
                score += 2

        return score

    def _calculate_caps_ratio(self, text: str) -> float:
        """Calculate ratio of capital letters (indicates shouting/anger)"""
        if not text:
            return 0.0

        caps_count = sum(1 for c in text if c.isupper())
        letter_count = sum(1 for c in text if c.isalpha())

        if letter_count == 0:
            return 0.0

        return caps_count / letter_count

    def get_emotion_indicators(self, text: str) -> Dict[str, bool]:
        """
        Get specific emotion indicators

        Returns:
            Dictionary with emotion flags
        """
        text_lower = text.lower()

        return {
            'angry': any(word in text_lower for word in ['angry', 'furious', 'outrage', 'unacceptable']),
            'frustrated': any(word in text_lower for word in ['frustrated', 'annoying', 'ridiculous']),
            'disappointed': any(word in text_lower for word in ['disappointed', 'let down', 'expected better']),
            'urgent': any(word in text_lower for word in self.urgency_intensifiers),
            'threatening': any(phrase in text_lower for phrase in ['cancel', 'report', 'lawyer', 'lawsuit']),
            'appreciative': any(word in text_lower for word in ['thank', 'appreciate', 'grateful'])
        }


if __name__ == "__main__":
    analyzer = SentimentAnalyzer()

    test_cases = [
        "Thank you so much for your excellent service!",
        "The app is not working and I'm very frustrated.",
        "I WANT MY MONEY BACK NOW!!! This is UNACCEPTABLE!!!",
        "Could you please help me with my billing question?",
        "URGENT: Production is DOWN! Critical issue!!!"
    ]

    print("Sentiment Analysis Test:\n")
    for text in test_cases:
        sentiment = analyzer.analyze(text)
        indicators = analyzer.get_emotion_indicators(text)
        print(f"Text: {text[:60]}...")
        print(f"Sentiment: {sentiment}")
        print(f"Indicators: {indicators}")
        print()
