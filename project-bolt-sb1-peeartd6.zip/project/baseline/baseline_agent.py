"""
Baseline Rule-Based Agent
Simple keyword-based classification and template responses for comparison
"""

import re
from typing import Dict, Any


class BaselineAgent:
    """
    Simple rule-based agent for comparison with AI agent
    Uses basic keyword matching and static templates
    """

    def __init__(self):
        """Initialize baseline agent with simple rules"""

        self.category_keywords = {
            'billing': ['charge', 'billing', 'invoice', 'payment', 'refund', 'credit', 'subscription', 'price'],
            'technical': ['error', 'bug', 'crash', 'broken', 'not working', 'api', 'slow', 'issue'],
            'account': ['password', 'login', 'account', 'access', 'locked', 'reset', '2fa'],
            'spam': ['won', 'winner', 'prize', 'million', 'click here', 'guarantee', 'free money']
        }

        self.response_templates = {
            'billing': (
                "Dear valued customer,\n\n"
                "Thank you for contacting us regarding your billing inquiry. "
                "We understand billing questions can be concerning, and we're here to help.\n\n"
                "Our billing team will review your account and respond within 24 hours with a detailed explanation. "
                "If you need immediate assistance, please don't hesitate to call our support line.\n\n"
                "Best regards,\n"
                "Customer Support Team"
            ),
            'technical': (
                "Hello,\n\n"
                "Thank you for reporting this technical issue. "
                "We take all technical problems seriously and will investigate this immediately.\n\n"
                "Our engineering team has been notified and will work to resolve this as quickly as possible. "
                "We'll keep you updated on the progress.\n\n"
                "Expected resolution time: 48 hours\n\n"
                "Technical Support Team"
            ),
            'account': (
                "Dear customer,\n\n"
                "Thank you for contacting us about your account. "
                "We're here to assist you with any account-related questions or changes.\n\n"
                "For security purposes, we may need to verify your identity before making any account modifications. "
                "Our team will reach out to you shortly with next steps.\n\n"
                "Best regards,\n"
                "Account Services Team"
            ),
            'spam': (
                "This email has been identified as potential spam and has been filtered accordingly."
            ),
            'other': (
                "Dear customer,\n\n"
                "Thank you for reaching out to us. We've received your message and will respond within 24-48 hours.\n\n"
                "If your matter is urgent, please contact our priority support line.\n\n"
                "Best regards,\n"
                "Customer Support Team"
            )
        }

    def process_email(self, email: Dict[str, Any]) -> Dict[str, Any]:
        """
        Process email using simple rule-based approach

        Args:
            email: Email dictionary with subject, body, customer_tier

        Returns:
            Decision dictionary with category, priority, sentiment, escalation, response
        """
        subject = email.get('subject', '')
        body = email.get('body', '')
        customer_tier = email.get('customer_tier', 'free')

        text = f"{subject} {body}".lower()

        category = self._classify_category(text)

        priority = self._assign_priority(text, customer_tier, category)

        sentiment = self._detect_sentiment(text)

        escalation = self._should_escalate(priority)

        response = self.response_templates[category]

        return {
            'category': category,
            'priority': priority,
            'sentiment': sentiment,
            'escalation': escalation,
            'response': response,
            'confidence': 0.5
        }

    def _classify_category(self, text: str) -> str:
        """
        Classify category using simple keyword matching

        Args:
            text: Email text

        Returns:
            Category string
        """
        category_scores = {}

        for category, keywords in self.category_keywords.items():
            score = sum(1 for keyword in keywords if keyword in text)
            category_scores[category] = score

        if category_scores['spam'] >= 2:
            return 'spam'

        max_score = max(category_scores.values())

        if max_score == 0:
            return 'other'

        for category, score in category_scores.items():
            if score == max_score and category != 'spam':
                return category

        return 'other'

    def _assign_priority(self, text: str, customer_tier: str, category: str) -> int:
        """
        Assign priority using simple rules

        Args:
            text: Email text
            customer_tier: Customer tier
            category: Email category

        Returns:
            Priority 1-5
        """
        if category == 'spam':
            return 1

        priority = 3

        if 'urgent' in text or 'immediately' in text or 'critical' in text:
            priority = 4

        if customer_tier == 'enterprise':
            priority = min(5, priority + 1)
        elif customer_tier == 'free':
            priority = max(1, priority - 1)

        return priority

    def _detect_sentiment(self, text: str) -> str:
        """
        Detect sentiment using simple keyword matching

        Args:
            text: Email text

        Returns:
            'positive', 'neutral', or 'negative'
        """
        negative_words = ['angry', 'frustrated', 'terrible', 'horrible', 'unacceptable', 'worst']
        positive_words = ['thank', 'appreciate', 'great', 'excellent', 'good']

        negative_count = sum(1 for word in negative_words if word in text)
        positive_count = sum(1 for word in positive_words if word in text)

        if text.count('!') >= 5 or text.upper() == text:
            negative_count += 1

        if negative_count > positive_count:
            return 'negative'
        elif positive_count > negative_count:
            return 'positive'
        else:
            return 'neutral'

    def _should_escalate(self, priority: int) -> bool:
        """
        Simple escalation rule: escalate if priority >= 5

        Args:
            priority: Priority level

        Returns:
            Boolean
        """
        return priority >= 5


if __name__ == "__main__":
    agent = BaselineAgent()

    test_email = {
        'subject': 'Billing issue with my account',
        'body': 'I was charged twice this month. Please help.',
        'customer_tier': 'premium'
    }

    result = agent.process_email(test_email)
    print("Baseline Agent Test:")
    print(f"Category: {result['category']}")
    print(f"Priority: {result['priority']}")
    print(f"Sentiment: {result['sentiment']}")
    print(f"Escalation: {result['escalation']}")
    print(f"\nResponse:\n{result['response']}")
