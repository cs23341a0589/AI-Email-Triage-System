"""
Demo Script - AI Email Triage System
Demonstrates the complete system with AI and Baseline agents
"""

import sys
import time
from env import EmailTriageEnv
from ai_engine import AIAgent
from baseline import BaselineAgent


def print_separator():
    print("\n" + "=" * 80 + "\n")


def demo_environment():
    """Demonstrate OpenEnv environment with dummy agent"""
    print("🎯 DEMO 1: OpenEnv Environment")
    print_separator()

    env = EmailTriageEnv(task_level="hard")
    obs = env.reset()

    print(f"Environment initialized with {len(env.emails)} emails")
    print(f"Task level: {env.task_level.upper()}")
    print(f"\nFirst email:")
    print(f"  Subject: {obs.subject}")
    print(f"  Customer: {obs.customer_tier}")
    print_separator()

    total_reward = 0
    count = 0

    while not env.done and count < 5:
        action = {
            'category': 'technical',
            'priority': 3,
            'response': 'Thank you for contacting us. We will look into this.',
            'escalation': False
        }

        obs, reward, done, info = env.step(action)
        total_reward += reward
        count += 1

        print(f"Email {count}:")
        print(f"  Reward: {reward:.3f}")
        print(f"  Category correct: {info.get('category_correct', 'N/A')}")
        if not done and obs:
            print(f"  Next: {obs.subject[:50]}...")
        print()

    print(f"Demo stopped after {count} emails")
    print(f"Average reward: {total_reward / count:.3f}")
    print_separator()


def demo_ai_agent():
    """Demonstrate AI Agent with intelligent decision making"""
    print("🤖 DEMO 2: AI Agent (Intelligent Decision Making)")
    print_separator()

    agent = AIAgent()

    test_emails = [
        {
            'subject': 'URGENT: Production API is DOWN!',
            'body': 'Our entire production system is down due to API failures. This is affecting 10,000 customers. Need immediate help!',
            'customer_tier': 'enterprise'
        },
        {
            'subject': 'Question about billing',
            'body': 'Hi, I have a quick question about my invoice. Could you explain the platform fee?',
            'customer_tier': 'free'
        },
        {
            'subject': 'Thank you!',
            'body': 'Just wanted to say thank you for the excellent support. Your team is amazing!',
            'customer_tier': 'premium'
        }
    ]

    for i, email in enumerate(test_emails, 1):
        print(f"Email {i}: {email['subject']}")
        print(f"Customer: {email['customer_tier']}")
        print()

        result = agent.process_email(email)

        print(f"AI Decision:")
        print(f"  📂 Category: {result['category']}")
        print(f"  ⚡ Priority: {result['priority']}/5")
        print(f"  😊 Sentiment: {result['sentiment']}")
        print(f"  🚨 Escalation: {result['escalation']}")
        print(f"  🎯 Confidence: {result['confidence']:.2%}")
        print(f"\n  💬 Response Preview:")
        print(f"     {result['response'][:100]}...")
        print_separator()


def demo_baseline_agent():
    """Demonstrate Baseline Agent for comparison"""
    print("📋 DEMO 3: Baseline Agent (Rule-Based)")
    print_separator()

    agent = BaselineAgent()

    test_email = {
        'subject': 'Billing issue with my account',
        'body': 'I was charged twice this month. Please help.',
        'customer_tier': 'premium'
    }

    print(f"Email: {test_email['subject']}")
    print(f"Customer: {test_email['customer_tier']}")
    print()

    result = agent.process_email(test_email)

    print(f"Baseline Decision:")
    print(f"  📂 Category: {result['category']}")
    print(f"  ⚡ Priority: {result['priority']}/5")
    print(f"  😊 Sentiment: {result['sentiment']}")
    print(f"  🚨 Escalation: {result['escalation']}")
    print(f"\n  💬 Response (Template):")
    print(f"     {result['response'][:100]}...")
    print_separator()


def demo_comparison():
    """Compare AI vs Baseline on same email"""
    print("⚖️  DEMO 4: AI vs Baseline Comparison")
    print_separator()

    ai_agent = AIAgent()
    baseline_agent = BaselineAgent()

    test_email = {
        'subject': 'CRITICAL: Data loss after update!!!',
        'body': 'ALL OUR DATA IS GONE after this morning\'s update! This is affecting 50 people in our team. We need this fixed IMMEDIATELY or we\'re facing serious consequences!',
        'customer_tier': 'enterprise'
    }

    print(f"Email: {test_email['subject']}")
    print(f"Customer: {test_email['customer_tier']}")
    print()

    print("🤖 AI Agent Decision:")
    ai_result = ai_agent.process_email(test_email)
    print(f"  Category: {ai_result['category']}")
    print(f"  Priority: {ai_result['priority']}/5")
    print(f"  Sentiment: {ai_result['sentiment']}")
    print(f"  Escalation: {ai_result['escalation']}")
    print(f"  Confidence: {ai_result['confidence']:.2%}")
    print()

    print("📋 Baseline Agent Decision:")
    baseline_result = baseline_agent.process_email(test_email)
    print(f"  Category: {baseline_result['category']}")
    print(f"  Priority: {baseline_result['priority']}/5")
    print(f"  Sentiment: {baseline_result['sentiment']}")
    print(f"  Escalation: {baseline_result['escalation']}")
    print(f"  Confidence: {baseline_result['confidence']:.2%}")
    print()

    print("📊 Analysis:")
    print(f"  AI detected higher urgency: Priority {ai_result['priority']} vs {baseline_result['priority']}")
    print(f"  AI sentiment analysis: {ai_result['sentiment']} vs {baseline_result['sentiment']}")
    print(f"  AI escalation decision: {ai_result['escalation']} (more context-aware)")
    print_separator()


def demo_full_pipeline():
    """Demonstrate full pipeline with environment + AI agent"""
    print("🚀 DEMO 5: Full Pipeline (Environment + AI Agent)")
    print_separator()

    env = EmailTriageEnv(task_level="hard")
    agent = AIAgent()

    obs = env.reset()
    print(f"Running AI agent on {len(env.emails)} emails...")
    print()

    total_reward = 0
    count = 0

    while not env.done and count < 10:
        email_data = {
            'subject': obs.subject,
            'body': obs.body,
            'customer_tier': obs.customer_tier
        }

        result = agent.process_email(email_data)

        action = {
            'category': result['category'],
            'priority': result['priority'],
            'response': result['response'],
            'escalation': result['escalation']
        }

        obs, reward, done, info = env.step(action)
        total_reward += reward
        count += 1

        print(f"✓ Email {count}: Reward = {reward:.3f} | Category: {result['category']} | Priority: {result['priority']}")

    print()
    print(f"Pipeline complete!")
    print(f"Processed: {count} emails")
    print(f"Average reward: {total_reward / count:.3f}")
    print_separator()


def main():
    print("\n" + "=" * 80)
    print("  AI EMAIL TRIAGE SYSTEM - COMPLETE DEMONSTRATION")
    print("  Production-Grade Email Automation with OpenEnv Training")
    print("=" * 80 + "\n")

    demos = [
        ("OpenEnv Environment", demo_environment),
        ("AI Agent Intelligence", demo_ai_agent),
        ("Baseline Agent", demo_baseline_agent),
        ("AI vs Baseline", demo_comparison),
        ("Full Pipeline", demo_full_pipeline)
    ]

    print("Available demonstrations:")
    for i, (name, _) in enumerate(demos, 1):
        print(f"  {i}. {name}")
    print(f"  {len(demos) + 1}. Run all demos")
    print()

    try:
        choice = input("Select demo (1-6, or press Enter for all): ").strip()

        if not choice or choice == str(len(demos) + 1):
            for name, demo_func in demos:
                demo_func()
                time.sleep(1)
        else:
            idx = int(choice) - 1
            if 0 <= idx < len(demos):
                demos[idx][1]()
            else:
                print("Invalid choice")
    except KeyboardInterrupt:
        print("\n\nDemo interrupted by user")
    except Exception as e:
        print(f"\nError: {e}")

    print("\n" + "=" * 80)
    print("  Demo complete! Check the React dashboard for interactive UI.")
    print("  Run: npm run dev")
    print("=" * 80 + "\n")


if __name__ == "__main__":
    main()
