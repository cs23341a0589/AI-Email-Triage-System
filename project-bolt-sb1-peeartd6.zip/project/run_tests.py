"""
Test Suite for AI Email Triage System
Validates environment, agents, and overall system functionality
"""

import sys
from env import EmailTriageEnv
from ai_engine import AIAgent
from baseline import BaselineAgent


def test_environment():
    """Test OpenEnv environment functionality"""
    print("\n" + "="*60)
    print("TEST 1: OpenEnv Environment")
    print("="*60)

    try:
        env = EmailTriageEnv(task_level="easy")
        obs = env.reset()

        assert obs is not None, "Reset should return observation"
        assert hasattr(obs, 'email_id'), "Observation should have email_id"
        assert hasattr(obs, 'subject'), "Observation should have subject"
        assert hasattr(obs, 'body'), "Observation should have body"

        action = {
            'category': 'technical',
            'priority': 3,
            'response': 'Test response',
            'escalation': False
        }

        obs, reward, done, info = env.step(action)

        assert 0 <= reward <= 1, f"Reward should be 0-1, got {reward}"
        assert isinstance(done, bool), "Done should be boolean"
        assert isinstance(info, dict), "Info should be dictionary"

        print("✓ Environment reset works")
        print("✓ Step function works")
        print("✓ Reward is bounded [0, 1]")
        print("✓ All assertions passed!")

        return True

    except Exception as e:
        print(f"✗ Test failed: {e}")
        return False


def test_ai_agent():
    """Test AI agent processing"""
    print("\n" + "="*60)
    print("TEST 2: AI Agent")
    print("="*60)

    try:
        agent = AIAgent()

        test_email = {
            'subject': 'Urgent billing issue',
            'body': 'I was charged twice for my subscription.',
            'customer_tier': 'premium'
        }

        result = agent.process_email(test_email)

        assert 'category' in result, "Result should have category"
        assert 'priority' in result, "Result should have priority"
        assert 'sentiment' in result, "Result should have sentiment"
        assert 'escalation' in result, "Result should have escalation"
        assert 'response' in result, "Result should have response"

        assert result['category'] in ['billing', 'technical', 'account', 'spam', 'other'], \
            f"Invalid category: {result['category']}"

        assert 1 <= result['priority'] <= 5, \
            f"Priority should be 1-5, got {result['priority']}"

        assert result['sentiment'] in ['positive', 'neutral', 'negative'], \
            f"Invalid sentiment: {result['sentiment']}"

        assert isinstance(result['escalation'], bool), \
            "Escalation should be boolean"

        assert len(result['response']) > 0, \
            "Response should not be empty"

        print(f"✓ AI Agent processed email")
        print(f"  Category: {result['category']}")
        print(f"  Priority: {result['priority']}/5")
        print(f"  Sentiment: {result['sentiment']}")
        print(f"  Escalation: {result['escalation']}")
        print("✓ All assertions passed!")

        return True

    except Exception as e:
        print(f"✗ Test failed: {e}")
        return False


def test_baseline_agent():
    """Test baseline agent processing"""
    print("\n" + "="*60)
    print("TEST 3: Baseline Agent")
    print("="*60)

    try:
        agent = BaselineAgent()

        test_email = {
            'subject': 'Account login problem',
            'body': 'Cannot access my account after password reset.',
            'customer_tier': 'free'
        }

        result = agent.process_email(test_email)

        assert 'category' in result, "Result should have category"
        assert 'priority' in result, "Result should have priority"
        assert result['category'] in ['billing', 'technical', 'account', 'spam', 'other']
        assert 1 <= result['priority'] <= 5

        print(f"✓ Baseline Agent processed email")
        print(f"  Category: {result['category']}")
        print(f"  Priority: {result['priority']}/5")
        print("✓ All assertions passed!")

        return True

    except Exception as e:
        print(f"✗ Test failed: {e}")
        return False


def test_reward_computation():
    """Test reward computation for different task levels"""
    print("\n" + "="*60)
    print("TEST 4: Reward Computation")
    print("="*60)

    try:
        for task_level in ['easy', 'medium', 'hard']:
            env = EmailTriageEnv(task_level=task_level)
            obs = env.reset()

            gt = env.get_ground_truth(0)

            action = {
                'category': gt.category,
                'priority': gt.priority,
                'response': gt.expected_response,
                'escalation': gt.escalation
            }

            obs, reward, done, info = env.step(action)

            assert reward >= 0.5, f"Perfect match should have high reward in {task_level} mode"

            print(f"✓ {task_level.upper()} mode: reward = {reward:.3f}")

        print("✓ All reward computations correct!")
        return True

    except Exception as e:
        print(f"✗ Test failed: {e}")
        return False


def test_escalation_logic():
    """Test escalation decision logic"""
    print("\n" + "="*60)
    print("TEST 5: Escalation Logic")
    print("="*60)

    try:
        agent = AIAgent()

        critical_email = {
            'subject': 'CRITICAL: Data loss in production',
            'body': 'ALL data is gone! This is affecting our entire business!',
            'customer_tier': 'enterprise'
        }

        result = agent.process_email(critical_email)

        assert result['priority'] == 5, "Critical email should have priority 5"
        assert result['escalation'] == True, "Critical email should escalate"

        print("✓ Critical email correctly escalated")

        spam_email = {
            'subject': 'You won $1,000,000!',
            'body': 'Click here to claim your prize now!',
            'customer_tier': 'free'
        }

        result = agent.process_email(spam_email)

        assert result['category'] == 'spam', "Should detect spam"
        assert result['escalation'] == False, "Spam should not escalate"

        print("✓ Spam correctly filtered without escalation")
        print("✓ All escalation logic correct!")

        return True

    except Exception as e:
        print(f"✗ Test failed: {e}")
        return False


def test_sentiment_analysis():
    """Test sentiment detection"""
    print("\n" + "="*60)
    print("TEST 6: Sentiment Analysis")
    print("="*60)

    try:
        agent = AIAgent()

        angry_email = {
            'subject': 'THIS IS UNACCEPTABLE!!!',
            'body': 'I am FURIOUS! This is the WORST service ever!',
            'customer_tier': 'premium'
        }

        result = agent.process_email(angry_email)
        assert result['sentiment'] == 'negative', "Should detect negative sentiment"
        print("✓ Negative sentiment detected correctly")

        happy_email = {
            'subject': 'Thank you!',
            'body': 'Excellent service! Very happy with the support.',
            'customer_tier': 'premium'
        }

        result = agent.process_email(happy_email)
        assert result['sentiment'] == 'positive', "Should detect positive sentiment"
        print("✓ Positive sentiment detected correctly")

        print("✓ All sentiment analysis correct!")

        return True

    except Exception as e:
        print(f"✗ Test failed: {e}")
        return False


def run_all_tests():
    """Run complete test suite"""
    print("\n" + "="*60)
    print("AI EMAIL TRIAGE SYSTEM - TEST SUITE")
    print("="*60)

    tests = [
        ("Environment", test_environment),
        ("AI Agent", test_ai_agent),
        ("Baseline Agent", test_baseline_agent),
        ("Reward Computation", test_reward_computation),
        ("Escalation Logic", test_escalation_logic),
        ("Sentiment Analysis", test_sentiment_analysis)
    ]

    results = []

    for name, test_func in tests:
        try:
            result = test_func()
            results.append((name, result))
        except Exception as e:
            print(f"\n✗ {name} test crashed: {e}")
            results.append((name, False))

    print("\n" + "="*60)
    print("TEST RESULTS SUMMARY")
    print("="*60)

    passed = sum(1 for _, result in results if result)
    total = len(results)

    for name, result in results:
        status = "✓ PASSED" if result else "✗ FAILED"
        print(f"{name:25s} {status}")

    print("\n" + "="*60)
    print(f"Results: {passed}/{total} tests passed")

    if passed == total:
        print("🎉 ALL TESTS PASSED! System is working correctly.")
        print("="*60 + "\n")
        return 0
    else:
        print("⚠️  Some tests failed. Please review the output above.")
        print("="*60 + "\n")
        return 1


if __name__ == "__main__":
    sys.exit(run_all_tests())
